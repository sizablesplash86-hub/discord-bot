/*
 * Copyright 2015 Austin Keener, Michael Ritter, Florian Spieß, and the JDA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.dv8tion.jda.api.entities;

import net.dv8tion.jda.annotations.Incubating;
import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.Permission;
import net.dv8tion.jda.api.Region;
import net.dv8tion.jda.api.entities.automod.AutoModResponse;
import net.dv8tion.jda.api.entities.automod.AutoModRule;
import net.dv8tion.jda.api.entities.automod.AutoModTriggerType;
import net.dv8tion.jda.api.entities.automod.build.AutoModRuleData;
import net.dv8tion.jda.api.entities.channel.Channel;
import net.dv8tion.jda.api.entities.channel.ChannelType;
import net.dv8tion.jda.api.entities.channel.attribute.ICopyableChannel;
import net.dv8tion.jda.api.entities.channel.attribute.IGuildChannelContainer;
import net.dv8tion.jda.api.entities.channel.attribute.IInviteContainer;
import net.dv8tion.jda.api.entities.channel.concrete.*;
import net.dv8tion.jda.api.entities.channel.middleman.AudioChannel;
import net.dv8tion.jda.api.entities.channel.middleman.GuildChannel;
import net.dv8tion.jda.api.entities.channel.middleman.MessageChannel;
import net.dv8tion.jda.api.entities.channel.middleman.StandardGuildChannel;
import net.dv8tion.jda.api.entities.channel.unions.DefaultGuildChannelUnion;
import net.dv8tion.jda.api.entities.detached.IDetachableEntity;
import net.dv8tion.jda.api.entities.emoji.CustomEmoji;
import net.dv8tion.jda.api.entities.emoji.RichCustomEmoji;
import net.dv8tion.jda.api.entities.guild.SecurityIncidentActions;
import net.dv8tion.jda.api.entities.guild.SecurityIncidentDetections;
import net.dv8tion.jda.api.entities.guild.SystemChannelFlag;
import net.dv8tion.jda.api.entities.sticker.*;
import net.dv8tion.jda.api.entities.templates.Template;
import net.dv8tion.jda.api.exceptions.InsufficientPermissionException;
import net.dv8tion.jda.api.interactions.DiscordLocale;
import net.dv8tion.jda.api.interactions.commands.Command;
import net.dv8tion.jda.api.interactions.commands.PrivilegeConfig;
import net.dv8tion.jda.api.interactions.commands.build.CommandData;
import net.dv8tion.jda.api.interactions.commands.build.Commands;
import net.dv8tion.jda.api.interactions.commands.privileges.IntegrationPrivilege;
import net.dv8tion.jda.api.managers.*;
import net.dv8tion.jda.api.requests.ErrorResponse;
import net.dv8tion.jda.api.requests.GatewayIntent;
import net.dv8tion.jda.api.requests.RestAction;
import net.dv8tion.jda.api.requests.restaction.*;
import net.dv8tion.jda.api.requests.restaction.order.CategoryOrderAction;
import net.dv8tion.jda.api.requests.restaction.order.ChannelOrderAction;
import net.dv8tion.jda.api.requests.restaction.order.RoleOrderAction;
import net.dv8tion.jda.api.requests.restaction.pagination.AuditLogPaginationAction;
import net.dv8tion.jda.api.requests.restaction.pagination.BanPaginationAction;
import net.dv8tion.jda.api.requests.restaction.pagination.PaginationAction;
import net.dv8tion.jda.api.utils.*;
import net.dv8tion.jda.api.utils.DiscordAssets;
import net.dv8tion.jda.api.utils.cache.*;
import net.dv8tion.jda.api.utils.concurrent.Task;
import net.dv8tion.jda.internal.interactions.CommandDataImpl;
import net.dv8tion.jda.internal.requests.DeferredRestAction;
import net.dv8tion.jda.internal.utils.Checks;
import net.dv8tion.jda.internal.utils.EntityString;
import net.dv8tion.jda.internal.utils.Helpers;
import net.dv8tion.jda.internal.utils.concurrent.task.GatewayTask;
import org.jetbrains.annotations.Unmodifiable;

import java.time.Duration;
import java.time.OffsetDateTime;
import java.time.temporal.TemporalAccessor;
import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import javax.annotation.CheckReturnValue;
import javax.annotation.Nonnull;
import javax.annotation.Nullable;

/**
 * Represents a Discord {@link net.dv8tion.jda.api.entities.Guild Guild}.
 * This should contain all information provided from Discord about a Guild.
 *
 * @see JDA#getGuildCache()
 * @see JDA#getGuildById(long)
 * @see JDA#getGuildsByName(String, boolean)
 * @see JDA#getGuilds()
 */
public interface Guild extends IGuildChannelContainer<GuildChannel>, ISnowflake, IDetachableEntity {
    /**
     * Template for {@link #getIconUrl()}.
     *
     * @deprecated Replaced by {@link DiscordAssets#guildIcon(ImageFormat, String, String)}
     */
    @Deprecated
    String ICON_URL = "https://cdn.discordapp.com/icons/%s/%s.%s";
    /**
     * Template for {@link #getSplashUrl()}.
     *
     * @deprecated Replaced by {@link DiscordAssets#guildSplash(ImageFormat, String, String)}
     */
    @Deprecated
    String SPLASH_URL = "https://cdn.discordapp.com/splashes/%s/%s.png";
    /**
     * Template for {@link #getBannerUrl()}.
     *
     * @deprecated Replaced by {@link DiscordAssets#guildBanner(ImageFormat, String, String)}
     */
    @Deprecated
    String BANNER_URL = "https://cdn.discordapp.com/banners/%s/%s.%s";

    /**
     * Retrieves the list of guild commands.
     * <br>This list does not include global commands! Use {@link JDA#retrieveCommands()} for global commands.
     * <br>This list does not include localization data. Use {@link #retrieveCommands(boolean)} to get localization data
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link List} of {@link Command}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<List<Command>> retrieveCommands() {
        return retrieveCommands(false);
    }

    /**
     * Retrieves the list of guild commands.
     * <br>This list does not include global commands! Use {@link JDA#retrieveCommands()} for global commands.
     *
     * @param  withLocalizations
     *         {@code true} if the localization data (such as name and description) should be included
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link List} of {@link Command}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<List<Command>> retrieveCommands(boolean withLocalizations);

    /**
     * Retrieves the existing {@link Command} instance by id.
     *
     * <p>If there is no command with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  id
     *         The command id
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     * @throws IllegalArgumentException
     *         If the provided id is not a valid snowflake
     *
     * @return {@link RestAction} - Type: {@link Command}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Command> retrieveCommandById(@Nonnull String id);

    /**
     * Retrieves the existing {@link Command} instance by id.
     *
     * <p>If there is no command with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  id
     *         The command id
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link Command}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<Command> retrieveCommandById(long id) {
        return retrieveCommandById(Long.toUnsignedString(id));
    }

    /**
     * Creates or updates a command.
     * <br>If a command with the same name exists, it will be replaced.
     * This operation is idempotent.
     * Commands will persist between restarts of your bot, you only have to create a command once.
     *
     * <p>To specify a complete list of all commands you can use {@link #updateCommands()} instead.
     *
     * <p>You need the OAuth2 scope {@code "applications.commands"} in order to add commands to a guild.
     *
     * @param  command
     *         The {@link CommandData} for the command
     *
     * @throws IllegalArgumentException
     *         If null is provided
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link Command}
     *         <br>The RestAction used to create or update the command
     *
     * @see    Commands#slash(String, String) Commands.slash(...)
     * @see    Commands#message(String) Commands.message(...)
     * @see    Commands#user(String) Commands.user(...)
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Command> upsertCommand(@Nonnull CommandData command);

    /**
     * Creates or updates a slash command.
     * <br>If a command with the same name exists, it will be replaced.
     * This operation is idempotent.
     * Commands will persist between restarts of your bot, you only have to create a command once.
     *
     * <p>To specify a complete list of all commands you can use {@link #updateCommands()} instead.
     *
     * <p>You need the OAuth2 scope {@code "applications.commands"} in order to add commands to a guild.
     *
     * @param  name
     *         The lowercase alphanumeric (with dash) name, 1-32 characters
     * @param  description
     *         The description for the command, 1-100 characters
     *
     * @throws IllegalArgumentException
     *         If null is provided or the name/description do not meet the requirements
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link CommandCreateAction}
     */
    @Nonnull
    @CheckReturnValue
    default CommandCreateAction upsertCommand(@Nonnull String name, @Nonnull String description) {
        return (CommandCreateAction) upsertCommand(new CommandDataImpl(name, description));
    }

    /**
     * Configures the complete list of guild commands.
     * <br>This will replace the existing command list for this guild. You should only use this at most once on startup!
     *
     * <p>This operation is idempotent.
     * Commands will persist between restarts of your bot, you only have to create a command once.
     *
     * <p>You need the OAuth2 scope {@code "applications.commands"} in order to add commands to a guild.
     *
     * <p><b>Examples</b>
     *
     * <p>Set list to 2 commands:
     * {@snippet lang="java":
     * guild.updateCommands()
     *   .addCommands(Commands.slash("ping", "Gives the current ping"))
     *   .addCommands(Commands.slash("ban", "Ban the target user")
     *     .addOption(OptionType.USER, "user", "The user to ban", true))
     *     .setDefaultPermissions(DefaultMemberPermissions.enabledFor(Permission.BAN_MEMBERS))
     *   .queue();
     * }
     *
     * <p>Delete all commands:
     * {@snippet lang="java":
     * guild.updateCommands().queue();
     * }
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link CommandListUpdateAction}
     *
     * @see    JDA#updateCommands()
     */
    @Nonnull
    @CheckReturnValue
    CommandListUpdateAction updateCommands();

    /**
     * Edit an existing command by id.
     *
     * <p>If there is no command with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  type
     *         The command type
     * @param  id
     *         The id of the command to edit
     *
     * @throws IllegalArgumentException
     *         If the provided id is not a valid snowflake or the type is {@link Command.Type#UNKNOWN}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link CommandEditAction} used to edit the command
     */
    @Nonnull
    @CheckReturnValue
    CommandEditAction editCommandById(@Nonnull Command.Type type, @Nonnull String id);

    /**
     * Edit an existing command by id.
     *
     * <p>If there is no command with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  type
     *         The command type
     * @param  id
     *         The id of the command to edit
     *
     * @throws IllegalArgumentException
     *         If the type is {@link Command.Type#UNKNOWN}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link CommandEditAction} used to edit the command
     */
    @Nonnull
    @CheckReturnValue
    default CommandEditAction editCommandById(@Nonnull Command.Type type, long id) {
        return editCommandById(type, Long.toUnsignedString(id));
    }

    /**
     * Delete the command for this id.
     *
     * <p>If there is no command with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  commandId
     *         The id of the command that should be deleted
     *
     * @throws IllegalArgumentException
     *         If the provided id is not a valid snowflake
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Void> deleteCommandById(@Nonnull String commandId);

    /**
     * Delete the command for this id.
     *
     * <p>If there is no command with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  commandId
     *         The id of the command that should be deleted
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<Void> deleteCommandById(long commandId) {
        return deleteCommandById(Long.toUnsignedString(commandId));
    }

    /**
     * Retrieves the {@link IntegrationPrivilege IntegrationPrivileges} for the target with the specified ID.
     * <br><b>The ID can either be of a Command or Application!</b>
     *
     * <p>Moderators of a guild can modify these privileges through the Integrations Menu
     *
     * <p>If there is no command or application with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  targetId
     *         The id of the command (global or guild), or application
     *
     * @throws IllegalArgumentException
     *         If the id is not a valid snowflake
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link List} of {@link IntegrationPrivilege}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<List<IntegrationPrivilege>> retrieveIntegrationPrivilegesById(@Nonnull String targetId);

    /**
     * Retrieves the {@link IntegrationPrivilege IntegrationPrivileges} for the target with the specified ID.
     * <br><b>The ID can either be of a Command or Application!</b>
     *
     * <p>Moderators of a guild can modify these privileges through the Integrations Menu
     *
     * <p>If there is no command or application with the provided ID,
     * this RestAction fails with {@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_COMMAND ErrorResponse.UNKNOWN_COMMAND}
     *
     * @param  targetId
     *         The id of the command (global or guild), or application
     *
     * @throws IllegalArgumentException
     *         If the id is not a valid snowflake
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link List} of {@link IntegrationPrivilege}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<List<IntegrationPrivilege>> retrieveIntegrationPrivilegesById(long targetId) {
        return retrieveIntegrationPrivilegesById(Long.toUnsignedString(targetId));
    }

    /**
     * Retrieves the {@link IntegrationPrivilege IntegrationPrivileges} for the commands in this guild.
     * <br>The RestAction provides a {@link PrivilegeConfig} providing the privileges of this application and its commands.
     *
     * <p>Moderators of a guild can modify these privileges through the Integrations Menu
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link PrivilegeConfig}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<PrivilegeConfig> retrieveCommandPrivileges();

    /**
     * Retrieves the available regions for this Guild
     * <br>Shortcut for {@link #retrieveRegions(boolean) retrieveRegions(true)}
     * <br>This will include deprecated voice regions by default.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type {@link java.util.EnumSet EnumSet}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<EnumSet<Region>> retrieveRegions() {
        return retrieveRegions(true);
    }

    /**
     * Retrieves the available regions for this Guild
     *
     * @param  includeDeprecated
     *         Whether to include deprecated regions
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type {@link java.util.EnumSet EnumSet}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<EnumSet<Region>> retrieveRegions(boolean includeDeprecated);

    /**
     * Retrieves all current {@link AutoModRule AutoModRules} for this guild.
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link List} of {@link AutoModRule}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<@Unmodifiable List<AutoModRule>> retrieveAutoModRules();

    /**
     * Retrieves the {@link AutoModRule} for the provided id.
     *
     * @param  id
     *         The id of the rule
     *
     * @throws IllegalArgumentException
     *         If the provided id is not a valid snowflake
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link AutoModRule}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<AutoModRule> retrieveAutoModRuleById(@Nonnull String id);

    /**
     * Retrieves the {@link AutoModRule} for the provided id.
     *
     * @param  id
     *         The id of the rule
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link AutoModRule}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<AutoModRule> retrieveAutoModRuleById(long id) {
        return retrieveAutoModRuleById(Long.toUnsignedString(id));
    }

    /**
     * Creates a new {@link AutoModRule} for this guild.
     *
     * <p>You can only create a certain number of rules for each {@link AutoModTriggerType AutoModTriggerType}.
     * The maximum is provided by {@link AutoModTriggerType#getMaxPerGuild()}.
     *
     * @param  data
     *         The data for the new rule
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link AutoModRuleData#getRequiredPermissions() required permissions}
     * @throws IllegalStateException
     *         <ul>
     *             <li>If the provided data does not have any {@link AutoModResponse} configured</li>
     *             <li>If any of the configured {@link AutoModResponse AutoModResponses} is not supported by the {@link AutoModTriggerType}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction} - Type: {@link AutoModRule}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<AutoModRule> createAutoModRule(@Nonnull AutoModRuleData data);

    /**
     * Returns an {@link AutoModRuleManager}, which can be used to modify the rule for the provided id.
     * <p>The manager allows modifying multiple fields in a single request.
     * <br>You modify multiple fields in one request by chaining setters before calling {@link net.dv8tion.jda.api.requests.RestAction#queue() RestAction.queue()}.
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The manager instance
     */
    @Nonnull
    @CheckReturnValue
    AutoModRuleManager modifyAutoModRuleById(@Nonnull String id);

    /**
     * Returns an {@link AutoModRuleManager}, which can be used to modify the rule for the provided id.
     * <p>The manager allows modifying multiple fields in a single request.
     * <br>You modify multiple fields in one request by chaining setters before calling {@link net.dv8tion.jda.api.requests.RestAction#queue() RestAction.queue()}.
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The manager instance
     */
    @Nonnull
    @CheckReturnValue
    default AutoModRuleManager modifyAutoModRuleById(long id) {
        return modifyAutoModRuleById(Long.toUnsignedString(id));
    }

    /**
     * Deletes the {@link AutoModRule} for the provided id.
     *
     * @param  id
     *         The id of the rule
     *
     * @throws IllegalArgumentException
     *         If the provided id is not a valid snowflake
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction} - Type: {@link Void}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> deleteAutoModRuleById(@Nonnull String id);

    /**
     * Deletes the {@link AutoModRule} for the provided id.
     *
     * @param  id
     *         The id of the rule
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction} - Type: {@link Void}
     */
    @Nonnull
    @CheckReturnValue
    default AuditableRestAction<Void> deleteAutoModRuleById(long id) {
        return deleteAutoModRuleById(Long.toUnsignedString(id));
    }

    /**
     * Adds the user to this guild as a member.
     * <br>This requires an <b>OAuth2 Access Token</b> with the scope {@code guilds.join}.
     *
     * @param  accessToken
     *         The access token
     * @param  user
     *         The {@link UserSnowflake} for the member to add.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     *
     * @throws IllegalArgumentException
     *         If the access token is blank, empty, or null,
     *         or if the provided user reference is null or is already in this guild
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#CREATE_INSTANT_INVITE Permission.CREATE_INSTANT_INVITE}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link MemberAction MemberAction}
     *
     * @see    <a href="https://discord.com/developers/docs/topics/oauth2" target="_blank">Discord OAuth2 Documentation</a>
     */
    @Nonnull
    @CheckReturnValue
    MemberAction addMember(@Nonnull String accessToken, @Nonnull UserSnowflake user);

    /**
     * Whether this guild has loaded members.
     * <br>This will always be false if the {@link GatewayIntent#GUILD_MEMBERS GUILD_MEMBERS} intent is disabled.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return True, if members are loaded.
     */
    boolean isLoaded();

    /**
     * Re-apply the {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy} of this session to all {@link Member Members} of this Guild.
     *
     * <p><b>Example</b><br>
     * {@snippet lang="java":
     * // Check if the members of this guild have at least 50% bots (bot collection/farm)
     * public void checkBots(Guild guild) {
     *     // Keep in mind: This requires the GUILD_MEMBERS intent which is disabled in createDefault and createLight by default
     *     guild.retrieveMembers() // Load members CompletableFuture<Void> (async and eager)
     *          .thenApply((v) -> guild.getMemberCache()) // Turn into CompletableFuture<MemberCacheView>
     *          .thenAccept((members) -> {
     *              int total = members.size();
     *              // Casting to double to get a double as result of division, don't need to worry about precision with small counts like this
     *              double bots = (double) members.applyStream(stream ->
     *                  stream.map(Member::getUser)
     *                        .filter(User::isBot)
     *                        .count()); // Count bots
     *              if (bots / total > 0.5) // Check how many members are bots
     *                  System.out.println("More than 50% of members in this guild are bots");
     *          })
     *          .thenRun(guild::pruneMemberCache); // Then prune the cache
     * }
     * }
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @see #unloadMember(long)
     * @see JDA#unloadUser(long)
     */
    void pruneMemberCache();

    /**
     * Attempts to remove the user with the provided id from the member cache.
     * <br>If you attempt to remove the {@link JDA#getSelfUser() SelfUser} this will simply return {@code false}.
     *
     * <p>This should be used by an implementation of {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     * as an upstream request to remove a member. For example a Least-Recently-Used (LRU) cache might use this to drop
     * old members if the cache capacity is reached. Or a timeout cache could use this to remove expired members.
     *
     * @param  userId
     *         The target user id
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return True, if the cache was changed
     *
     * @see    #pruneMemberCache()
     * @see    JDA#unloadUser(long)
     */
    boolean unloadMember(long userId);

    /**
     * The expected member count for this guild.
     * <br>If this guild is not lazy loaded this should be identical to the size returned by {@link #getMemberCache()}.
     *
     * <p>When {@link net.dv8tion.jda.api.requests.GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS} is disabled, this will not be updated.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The expected member count for this guild
     */
    int getMemberCount();

    /**
     * The human readable name of the {@link net.dv8tion.jda.api.entities.Guild Guild}.
     * <p>
     * This value can be modified using {@link GuildManager#setName(String)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Never-null String containing the Guild's name.
     */
    @Nonnull
    String getName();

    /**
     * The Discord hash-id of the {@link net.dv8tion.jda.api.entities.Guild Guild} icon image.
     * If no icon has been set, this returns {@code null}.
     * <p>
     * The Guild icon can be modified using {@link GuildManager#setIcon(Icon)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null String containing the Guild's icon hash-id.
     */
    @Nullable
    String getIconId();

    /**
     * The URL of the {@link net.dv8tion.jda.api.entities.Guild Guild} icon image.
     * If no icon has been set, this returns {@code null}.
     * <p>
     * The Guild icon can be modified using {@link GuildManager#setIcon(Icon)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null String containing the Guild's icon URL.
     */
    @Nullable
    default String getIconUrl() {
        String iconId = getIconId();
        return iconId == null
                ? null
                : getIconUrl(iconId.startsWith("a_") ? ImageFormat.ANIMATED_WEBP : ImageFormat.PNG);
    }

    /**
     * The URL of the {@link net.dv8tion.jda.api.entities.Guild Guild} icon image.
     * If no icon has been set, this returns {@code null}.
     * <p>
     * The Guild icon can be modified using {@link GuildManager#setIcon(Icon)}.
     *
     * @param  format
     *         The format in which the image should be
     *
     * @throws IllegalArgumentException
     *         If the format is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null String containing the Guild's icon URL.
     *
     * @see    DiscordAssets#guildIcon(ImageFormat, String, String)
     */
    @Nullable
    default String getIconUrl(@Nonnull ImageFormat format) {
        ImageProxy icon = getIcon(format);
        return icon == null ? null : icon.getUrl();
    }

    /**
     * Returns an {@link ImageProxy} for this guild's icon.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The {@link ImageProxy} of this guild's icon
     *
     * @see    #getIconUrl()
     */
    @Nullable
    default ImageProxy getIcon() {
        String iconUrl = getIconUrl();
        return iconUrl == null ? null : new ImageProxy(iconUrl);
    }

    /**
     * Returns an {@link ImageProxy} for this guild's icon.
     *
     * @param  format
     *         The format in which the image should be
     *
     * @throws IllegalArgumentException
     *         If the format is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The {@link ImageProxy} of this guild's icon
     *
     * @see    #getIconUrl(ImageFormat)
     * @see    DiscordAssets#guildIcon(ImageFormat, String, String)
     */
    @Nullable
    default ImageProxy getIcon(@Nonnull ImageFormat format) {
        String iconId = getIconId();
        return iconId == null ? null : DiscordAssets.guildIcon(format, getId(), iconId);
    }

    /**
     * The Features of the {@link net.dv8tion.jda.api.entities.Guild Guild}.
     *
     * <p>Features can be updated using {@link GuildManager#setFeatures(Collection)}.
     *
     * @return Never-null, unmodifiable Set containing all of the Guild's features.
     *
     * @see <a target="_blank" href="https://discord.com/developers/docs/resources/guild#guild-object-guild-features">List of Features</a>
     */
    @Nonnull
    @Unmodifiable
    Set<String> getFeatures();

    /**
     * Whether the invites for this guild are paused/disabled.
     * <br>This is equivalent to {@code getFeatures().contains("INVITES_DISABLED")}.
     *
     * @return True, if invites are paused/disabled
     */
    default boolean isInvitesDisabled() {
        return getFeatures().contains("INVITES_DISABLED");
    }

    /**
     * The Discord hash-id of the splash image for this Guild. A Splash image is an image displayed when viewing a
     * Discord Guild Invite on the web or in client just before accepting or declining the invite.
     * If no splash has been set, this returns {@code null}.
     * <br>Splash images are VIP/Partner Guild only.
     * <p>
     * The Guild splash can be modified using {@link GuildManager#setSplash(Icon)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null String containing the Guild's splash hash-id
     */
    @Nullable
    String getSplashId();

    /**
     * The URL of the splash image for this Guild. A Splash image is an image displayed when viewing a
     * Discord Guild Invite on the web or in client just before accepting or declining the invite.
     * If no splash has been set, this returns {@code null}.
     * <br>Splash images are VIP/Partner Guild only.
     * <p>
     * The Guild splash can be modified using {@link GuildManager#setSplash(Icon)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null String containing the Guild's splash URL.
     */
    @Nullable
    default String getSplashUrl() {
        String splashId = getSplashId();
        return splashId == null ? null : getSplashUrl(ImageFormat.PNG);
    }

    /**
     * The URL of the splash image for this Guild. A Splash image is an image displayed when viewing a
     * Discord Guild Invite on the web or in client just before accepting or declining the invite.
     * If no splash has been set, this returns {@code null}.
     * <br>Splash images are VIP/Partner Guild only.
     * <p>
     * The Guild splash can be modified using {@link GuildManager#setSplash(Icon)}.
     *
     * @param  format
     *         The format in which the image should be
     *
     * @throws IllegalArgumentException
     *         If the format is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null String containing the Guild's splash URL.
     *
     * @see    DiscordAssets#guildSplash(ImageFormat, String, String)
     */
    @Nullable
    default String getSplashUrl(@Nonnull ImageFormat format) {
        ImageProxy splash = getSplash(format);
        return splash == null ? null : splash.getUrl();
    }

    /**
     * Returns an {@link ImageProxy} for this guild's splash icon.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link ImageProxy} of this guild's splash icon
     *
     * @see    #getSplashUrl()
     */
    @Nullable
    default ImageProxy getSplash() {
        String splashUrl = getSplashUrl();
        return splashUrl == null ? null : new ImageProxy(splashUrl);
    }

    /**
     * Returns an {@link ImageProxy} for this guild's splash icon.
     *
     * @param  format
     *         The format in which the image should be
     *
     * @throws IllegalArgumentException
     *         If the format is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link ImageProxy} of this guild's splash icon
     *
     * @see    #getSplashUrl(ImageFormat)
     * @see    DiscordAssets#guildSplash(ImageFormat, String, String)
     */
    @Nullable
    default ImageProxy getSplash(@Nonnull ImageFormat format) {
        return DiscordAssets.guildSplash(format, getId(), getSplashId());
    }

    /**
     * The vanity url code for this Guild. The vanity url is the custom invite code of partnered / official / boosted Guilds.
     * <br>The returned String will be the code that can be provided to {@code discord.gg/{code}} to get the invite link.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The vanity code or null
     *
     * @see    #getVanityUrl()
     */
    @Nullable
    String getVanityCode();

    /**
     * The vanity url for this Guild. The vanity url is the custom invite code of partnered / official / boosted Guilds.
     * <br>The returned String will be the vanity invite link to this guild.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The vanity url or null
     */
    @Nullable
    default String getVanityUrl() {
        return getVanityCode() == null ? null : "https://discord.gg/" + getVanityCode();
    }

    /**
     * Retrieves the Vanity Invite meta data for this guild.
     * <br>This allows you to inspect how many times the vanity invite has been used.
     * You can use {@link #getVanityUrl()} if you only care about the invite.
     *
     * <p>This action requires the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVITE_CODE_INVALID INVITE_CODE_INVALID}
     *     <br>If this guild does not have a vanity invite</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The vanity invite cannot be fetched due to a permission discrepancy</li>
     * </ul>
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have {@link Permission#MANAGE_SERVER Permission.MANAGE_SERVER}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link VanityInvite}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<VanityInvite> retrieveVanityInvite();

    /**
     * The description for this guild.
     * <br>This is displayed in the server browser below the guild name for verified guilds,
     * and in embedded invite links.
     *
     * <p>The description can be modified using {@link GuildManager#setDescription(String)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The description
     */
    @Nullable
    String getDescription();

    /**
     * The preferred locale for this guild.
     * <br>If the guild doesn't have the COMMUNITY feature, this returns the default.
     *
     * <br>Default: {@link DiscordLocale#ENGLISH_US}
     *
     * @return The preferred {@link DiscordLocale} for this guild
     */
    @Nonnull
    DiscordLocale getLocale();

    /**
     * The guild banner id.
     * <br>This is shown in guilds below the guild name.
     *
     * <p>The banner can be modified using {@link GuildManager#setBanner(Icon)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The guild banner id or null
     *
     * @see    #getBannerUrl(ImageFormat)
     */
    @Nullable
    String getBannerId();

    /**
     * The guild banner url.
     * <br>This is shown in guilds below the guild name.
     *
     * <p>The banner can be modified using {@link GuildManager#setBanner(Icon)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The guild banner url or null
     */
    @Nullable
    default String getBannerUrl() {
        String bannerId = getBannerId();
        return bannerId == null
                ? null
                : getBannerUrl(bannerId.startsWith("a_") ? ImageFormat.ANIMATED_WEBP : ImageFormat.PNG);
    }

    /**
     * The guild banner url.
     * <br>This is shown in guilds below the guild name.
     *
     * <p>The banner can be modified using {@link GuildManager#setBanner(Icon)}.
     *
     * @param  format
     *         The format in which the image should be
     *
     * @throws IllegalArgumentException
     *         If the format is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The guild banner url or null
     *
     * @see    DiscordAssets#guildBanner(ImageFormat, String, String)
     */
    @Nullable
    default String getBannerUrl(@Nonnull ImageFormat format) {
        ImageProxy banner = getBanner(format);
        return banner == null ? null : banner.getUrl();
    }

    /**
     * Returns an {@link ImageProxy} for this guild's banner image.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link ImageProxy} of this guild's banner image
     *
     * @see    #getBannerUrl()
     */
    @Nullable
    default ImageProxy getBanner() {
        String bannerUrl = getBannerUrl();
        return bannerUrl == null ? null : new ImageProxy(bannerUrl);
    }

    /**
     * Returns an {@link ImageProxy} for this guild's banner image.
     *
     * @param  format
     *         The format in which the image should be
     *
     * @throws IllegalArgumentException
     *         If the format is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link ImageProxy} of this guild's banner image
     *
     * @see    #getBannerUrl(ImageFormat)
     * @see    DiscordAssets#guildBanner(ImageFormat, String, String)
     */
    @Nullable
    default ImageProxy getBanner(@Nonnull ImageFormat format) {
        return DiscordAssets.guildBanner(format, getId(), getBannerId());
    }

    /**
     * The boost tier for this guild.
     * <br>Each tier unlocks new perks for a guild that can be seen in the {@link #getFeatures() features}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The boost tier.
     */
    @Nonnull
    BoostTier getBoostTier();

    /**
     * The amount of boosts this server currently has.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The boost count
     */
    int getBoostCount();

    /**
     * Sorted list of {@link Member Members} that boost this guild.
     * <br>The list is sorted by {@link Member#getTimeBoosted()} ascending.
     * This means the first element will be the member who has been boosting for the longest time.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Immutable list of members who boost this guild
     */
    @Nonnull
    @Unmodifiable
    List<Member> getBoosters();

    /**
     * The maximum bitrate that can be applied to a voice channel in this guild.
     * <br>This depends on the features of this guild that can be unlocked for partners or through boosting.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The maximum bitrate
     */
    default int getMaxBitrate() {
        int maxBitrate = getFeatures().contains("VIP_REGIONS") ? 384000 : 96000;
        return Math.max(maxBitrate, getBoostTier().getMaxBitrate());
    }

    /**
     * Returns the maximum size for files that can be uploaded to this Guild.
     * This returns 8 MiB for Guilds without a Boost Tier or Guilds with Boost Tier 1, 50 MiB for Guilds with Boost Tier 2 and 100 MiB for Guilds with Boost Tier 3.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The maximum size for files that can be uploaded to this Guild
     */
    default long getMaxFileSize() {
        return getBoostTier().getMaxFileSize();
    }

    /**
     * The maximum amount of custom emojis a guild can have based on the guilds boost tier.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The maximum amount of custom emojis
     */
    default int getMaxEmojis() {
        int max = getFeatures().contains("MORE_EMOJI") ? 200 : 50;
        return Math.max(max, getBoostTier().getMaxEmojis());
    }

    /**
     * The maximum amount of members that can join this guild.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The maximum amount of members
     *
     * @see    #retrieveMetaData()
     */
    int getMaxMembers();

    /**
     * The maximum amount of connected members this guild can have at a time.
     * <br>This includes members that are invisible but still connected to discord.
     * If too many members are online the guild will become unavailable for others.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The maximum amount of connected members this guild can have
     *
     * @see    #retrieveMetaData()
     */
    int getMaxPresences();

    /**
     * Loads {@link MetaData} for this guild instance.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link MetaData}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<MetaData> retrieveMetaData();

    /**
     * Provides the {@link VoiceChannel VoiceChannel} that has been set as the channel
     * which {@link Member Members} will be moved to after they have been inactive in a
     * {@link VoiceChannel VoiceChannel} for longer than {@link #getAfkTimeout()}.
     * <br>If no channel has been set as the AFK channel, this returns {@code null}.
     * <p>
     * This value can be modified using {@link GuildManager#setAfkChannel(VoiceChannel)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link VoiceChannel VoiceChannel} that is the AFK Channel.
     */
    @Nullable
    VoiceChannel getAfkChannel();

    /**
     * Provides the {@link TextChannel TextChannel} that has been set as the channel
     * which newly joined {@link Member Members} will be announced in.
     * <br>If no channel has been set as the system channel, this returns {@code null}.
     * <p>
     * This value can be modified using {@link GuildManager#setSystemChannel(TextChannel)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link TextChannel TextChannel} that is the system Channel.
     */
    @Nullable
    TextChannel getSystemChannel();

    /**
     * Provides the {@link TextChannel TextChannel} that lists the rules of the guild.
     * <br>If this guild doesn't have the COMMUNITY {@link #getFeatures() feature}, this returns {@code null}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link TextChannel TextChannel} that is the rules channel
     *
     * @see    #getFeatures()
     */
    @Nullable
    TextChannel getRulesChannel();

    /**
     * Provides the {@link TextChannel TextChannel} that receives community updates.
     * <br>If this guild doesn't have the COMMUNITY {@link #getFeatures() feature}, this returns {@code null}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link TextChannel TextChannel} that is the community updates channel
     *
     * @see    #getFeatures()
     */
    @Nullable
    TextChannel getCommunityUpdatesChannel();

    /**
     * Provides the {@link TextChannel TextChannel} that receives discord safety alerts.
     * <br>If this guild doesn't have the COMMUNITY {@link #getFeatures() feature}, this returns {@code null}.
     *
     * @return Possibly-null {@link TextChannel TextChannel} that is the saferty alerts channel.
     *
     * @see    #getFeatures()
     */
    @Nullable
    TextChannel getSafetyAlertsChannel();

    /**
     * The {@link Member Member} object for the owner of this Guild.
     * <br>This is null when the owner is no longer in this guild or not yet loaded (lazy loading).
     * Sometimes owners of guilds delete their account or get banned by Discord.
     *
     * <p>If lazy-loading is used it is recommended to use {@link #retrieveOwner()} instead.
     *
     * <p>This only works when the member was added to cache. Lazy loading might load this later.
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null Member object for the Guild owner.
     *
     * @see    #getOwnerIdLong()
     * @see    #retrieveOwner()
     */
    @Nullable
    Member getOwner();

    /**
     * The ID for the current owner of this guild.
     * <br>This is useful for debugging purposes or as a shortcut.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The ID for the current owner
     *
     * @see    #getOwner()
     */
    long getOwnerIdLong();

    /**
     * The ID for the current owner of this guild.
     * <br>This is useful for debugging purposes or as a shortcut.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The ID for the current owner
     *
     * @see    #getOwner()
     */
    @Nonnull
    default String getOwnerId() {
        return Long.toUnsignedString(getOwnerIdLong());
    }

    /**
     * The {@link net.dv8tion.jda.api.entities.Guild.Timeout Timeout} set for this Guild representing the amount of time
     * that must pass for a Member to have had no activity in a {@link VoiceChannel VoiceChannel}
     * to be considered AFK. If {@link #getAfkChannel()} is not {@code null} (thus an AFK channel has been set) then Member
     * will be automatically moved to the AFK channel after they have been inactive for longer than the returned Timeout.
     * <br>Default is {@link Timeout#SECONDS_300 300 seconds (5 minutes)}.
     * <p>
     * This value can be modified using {@link GuildManager#setAfkTimeout(net.dv8tion.jda.api.entities.Guild.Timeout)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The {@link net.dv8tion.jda.api.entities.Guild.Timeout Timeout} set for this Guild.
     */
    @Nonnull
    Timeout getAfkTimeout();

    /**
     * The current guild {@link SecurityIncidentActions security incident actions}.
     * <br>Security incident actions are used to temporarily disable features for the purpose of moderation.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link SecurityIncidentActions} the current actions
     */
    @Nonnull
    SecurityIncidentActions getSecurityIncidentActions();

    /**
     * The current security incident detections.
     * <br>Discord may automatically detect spammers or raiders.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link SecurityIncidentDetections} the current detections
     */
    @Nonnull
    SecurityIncidentDetections getSecurityIncidentDetections();

    /**
     * Used to determine if the provided {@link UserSnowflake} is a member of this Guild.
     *
     * <p>This will only check cached members! If the cache is not loaded (see {@link #isLoaded()}), this may return false despite the user being a member.
     * This is false when {@link #getMember(UserSnowflake)} returns {@code null}.
     *
     * @param  user
     *         The user to check
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return True - if this user is present and cached in this guild
     */
    boolean isMember(@Nonnull UserSnowflake user);

    /**
     * Gets the {@link Member Member} object of the currently logged in account in this guild.
     * <br>This is basically {@link net.dv8tion.jda.api.JDA#getSelfUser()} being provided to {@link #getMember(UserSnowflake)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The Member object of the currently logged in account.
     */
    @Nonnull
    SelfMember getSelfMember();

    /**
     * Returns the NSFW Level that this guild is classified with.
     * <br>For a short description of the different values, see {@link net.dv8tion.jda.api.entities.Guild.NSFWLevel NSFWLevel}.
     * <p>
     * This value can only be modified by Discord after reviewing the Guild.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The NSFWLevel of this guild.
     */
    @Nonnull
    NSFWLevel getNSFWLevel();

    /**
     * Returns a {@link Set} of {@link SystemChannelFlag} associated to the guild.
     * <br>For a description of what system channel flags represent, see {@link SystemChannelFlag}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}.
     *
     * @return An <b>unmodifiable</b> set of system channel flags of this guild.
     *
     * @see    <a href="https://discord.com/developers/docs/resources/guild#guild-object-system-channel-flags">
     *         System Channel Flags API documentation
     *         </a>
     */
    @Nonnull
    Set<SystemChannelFlag> getSystemChannelFlags();

    /**
     * Returns the bitmask of the {@linkplain SystemChannelFlag system channel flags} associated
     * to the guild. This method may be preferable over {@link Guild#getSystemChannelFlags()}
     * if new flags are introduced to the Discord API and the {@link SystemChannelFlag} enumeration
     * cannot yet accommodate the new flags.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}.
     *
     * @return An integer bitmask of system channel flags of this guild.
     *
     * @see    <a href="https://discord.com/developers/docs/resources/guild#guild-object-system-channel-flags">
     *         System Channel Flags API documentation
     *         </a>
     */
    int getSystemChannelFlagsRaw();

    /**
     * Gets the Guild specific {@link Member Member} object for the provided
     * {@link UserSnowflake}.
     * <br>If the user is not in this guild or currently uncached, {@code null} is returned.
     *
     * <p>This will only check cached members!
     *
     * @param  user
     *         The {@link UserSnowflake} for the member to get.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     *
     * @throws java.lang.IllegalArgumentException
     *         If the provided user is null
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link Member Member} for the related {@link net.dv8tion.jda.api.entities.User User}.
     *
     * @see    #retrieveMember(UserSnowflake)
     */
    @Nullable
    Member getMember(@Nonnull UserSnowflake user);

    /**
     * Gets a {@link Member Member} object via the id of the user. The id relates to
     * {@link net.dv8tion.jda.api.entities.User#getId()}, and this method is similar to {@link JDA#getUserById(String)}
     * <br>This is more efficient that using {@link JDA#getUserById(String)} and {@link #getMember(UserSnowflake)}.
     * <br>If no Member in this Guild has the {@code userId} provided, this returns {@code null}.
     *
     * <p>This will only check cached members!
     *
     * @param  userId
     *         The Discord id of the User for which a Member object is requested.
     *
     * @throws java.lang.NumberFormatException
     *         If the provided {@code id} cannot be parsed by {@link Long#parseLong(String)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link Member Member} with the related {@code userId}.
     *
     * @see    #retrieveMemberById(String)
     */
    @Nullable
    default Member getMemberById(@Nonnull String userId) {
        return getMemberCache().getElementById(userId);
    }

    /**
     * Gets a {@link Member Member} object via the id of the user. The id relates to
     * {@link net.dv8tion.jda.api.entities.User#getIdLong()}, and this method is similar to {@link JDA#getUserById(long)}
     * <br>This is more efficient that using {@link JDA#getUserById(long)} and {@link #getMember(UserSnowflake)}.
     * <br>If no Member in this Guild has the {@code userId} provided, this returns {@code null}.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @param  userId
     *         The Discord id of the User for which a Member object is requested.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link Member Member} with the related {@code userId}.
     *
     * @see    #retrieveMemberById(long)
     */
    @Nullable
    default Member getMemberById(long userId) {
        return getMemberCache().getElementById(userId);
    }

    /**
     * Searches for a {@link Member} that has the matching Discord Tag.
     * <br>Format has to be in the form {@code Username#Discriminator} where the
     * username must be between 2 and 32 characters (inclusive) matching the exact casing and the discriminator
     * must be exactly 4 digits.
     * <br>This does not check the {@link Member#getNickname() nickname} of the member
     * but the username.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * <p>This only checks users that are in this guild. If a user exists
     * with the tag that is not available in the {@link #getMemberCache() Member-Cache} it will not be detected.
     * <br>Currently Discord does not offer a way to retrieve a user by their discord tag.
     *
     * @param  tag
     *         The Discord Tag in the format {@code Username#Discriminator}
     *
     * @throws java.lang.IllegalArgumentException
     *         If the provided tag is null or not in the described format
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The {@link Member} for the discord tag or null if no member has the provided tag
     *
     * @see    net.dv8tion.jda.api.JDA#getUserByTag(String)
     */
    @Nullable
    default Member getMemberByTag(@Nonnull String tag) {
        User user = getJDA().getUserByTag(tag);
        return user == null ? null : getMember(user);
    }

    /**
     * Searches for a {@link Member} that has the matching Discord Tag.
     * <br>Format has to be in the form {@code Username#Discriminator} where the
     * username must be between 2 and 32 characters (inclusive) matching the exact casing and the discriminator
     * must be exactly 4 digits.
     * <br>This does not check the {@link Member#getNickname() nickname} of the member
     * but the username.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * <p>This only checks users that are in this guild. If a user exists
     * with the tag that is not available in the {@link #getMemberCache() Member-Cache} it will not be detected.
     * <br>Currently Discord does not offer a way to retrieve a user by their discord tag.
     *
     * @param  username
     *         The name of the user
     * @param  discriminator
     *         The discriminator of the user
     *
     * @throws java.lang.IllegalArgumentException
     *         If the provided arguments are null or not in the described format
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The {@link Member} for the discord tag or null if no member has the provided tag
     *
     * @see    #getMemberByTag(String)
     */
    @Nullable
    default Member getMemberByTag(@Nonnull String username, @Nonnull String discriminator) {
        User user = getJDA().getUserByTag(username, discriminator);
        return user == null ? null : getMember(user);
    }

    /**
     * A list of all {@link Member Members} in this Guild.
     * <br>The Members are not provided in any particular order.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * <p>This copies the backing store into a list. This means every call
     * creates a new list with O(n) complexity. It is recommended to store this into
     * a local variable or use {@link #getMemberCache()} and use its more efficient
     * versions of handling these values.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Immutable list of all <b>cached</b> members in this Guild.
     *
     * @see    #loadMembers()
     */
    @Nonnull
    @Unmodifiable
    default List<Member> getMembers() {
        return getMemberCache().asList();
    }

    /**
     * Gets a list of all {@link Member Members} who have the same name as the one provided.
     * <br>This compares against {@link Member#getUser()}{@link net.dv8tion.jda.api.entities.User#getName() .getName()}
     * <br>If there are no {@link Member Members} with the provided name, then this returns an empty list.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @param  name
     *         The name used to filter the returned Members.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws IllegalArgumentException
     *         If the provided name is null
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all Members with the same name as the name provided.
     *
     * @see    #retrieveMembersByPrefix(String, int)
     *
     * @incubating This will be replaced in the future when the rollout of globally unique usernames has been completed.
     */
    @Nonnull
    @Incubating
    @Unmodifiable
    default List<Member> getMembersByName(@Nonnull String name, boolean ignoreCase) {
        return getMemberCache().getElementsByUsername(name, ignoreCase);
    }

    /**
     * Gets a list of all {@link Member Members} who have the same nickname as the one provided.
     * <br>This compares against {@link Member#getNickname()}. If a Member does not have a nickname, the comparison results as false.
     * <br>If there are no {@link Member Members} with the provided name, then this returns an empty list.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @param  nickname
     *         The nickname used to filter the returned Members.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all Members with the same nickname as the nickname provided.
     *
     * @see    #retrieveMembersByPrefix(String, int)
     */
    @Nonnull
    @Unmodifiable
    default List<Member> getMembersByNickname(@Nullable String nickname, boolean ignoreCase) {
        return getMemberCache().getElementsByNickname(nickname, ignoreCase);
    }

    /**
     * Gets a list of all {@link Member Members} who have the same effective name as the one provided.
     * <br>This compares against {@link Member#getEffectiveName()}.
     * <br>If there are no {@link Member Members} with the provided name, then this returns an empty list.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @param  name
     *         The name used to filter the returned Members.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws IllegalArgumentException
     *         If the provided name is null
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all Members with the same effective name as the name provided.
     *
     * @see    #retrieveMembersByPrefix(String, int)
     */
    @Nonnull
    @Unmodifiable
    default List<Member> getMembersByEffectiveName(@Nonnull String name, boolean ignoreCase) {
        return getMemberCache().getElementsByName(name, ignoreCase);
    }

    /**
     * Gets a list of {@link Member Members} that have all {@link Role Roles} provided.
     * <br>If there are no {@link Member Members} with all provided roles, then this returns an empty list.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @param  roles
     *         The {@link Role Roles} that a {@link Member Member}
     *         must have to be included in the returned list.
     *
     * @throws java.lang.IllegalArgumentException
     *         If a provided {@link Role Role} is from a different guild or null.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of Members with all provided Roles.
     *
     * @see    #findMembersWithRoles(Role...)
     */
    @Nonnull
    @Unmodifiable
    default List<Member> getMembersWithRoles(@Nonnull Role... roles) {
        Checks.notNull(roles, "Roles");
        return getMembersWithRoles(Arrays.asList(roles));
    }

    /**
     * Gets a list of {@link Member Members} that have all provided {@link Role Roles}.
     * <br>If there are no {@link Member Members} with all provided roles, then this returns an empty list.
     *
     * <p>This will only check cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @param  roles
     *         The {@link Role Roles} that a {@link Member Member}
     *         must have to be included in the returned list.
     *
     * @throws java.lang.IllegalArgumentException
     *         If a provided {@link Role Role} is from a different guild or null.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of Members with all provided Roles.
     *
     * @see    #findMembersWithRoles(Collection)
     */
    @Nonnull
    @Unmodifiable
    default List<Member> getMembersWithRoles(@Nonnull Collection<Role> roles) {
        Checks.noneNull(roles, "Roles");
        for (Role role : roles) {
            Checks.check(this.equals(role.getGuild()), "All roles must be from the same guild!");
        }
        return getMemberCache().getElementsWithRoles(roles);
    }

    /**
     * {@link net.dv8tion.jda.api.utils.cache.MemberCacheView MemberCacheView} for all cached
     * {@link Member Members} of this Guild.
     *
     * <p>This will only provide cached members!
     * <br>See {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.utils.cache.MemberCacheView MemberCacheView}
     *
     * @see    #loadMembers()
     */
    @Nonnull
    MemberCacheView getMemberCache();

    /**
     * Sorted {@link SnowflakeCacheView} of
     * all cached {@link ScheduledEvent ScheduledEvents} of this Guild.
     * <br>Scheduled events are sorted by their start time, and events that start at the same time
     * are sorted by their snowflake ID.
     *
     * <p>This requires {@link CacheFlag#SCHEDULED_EVENTS} to be enabled.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link SortedSnowflakeCacheView}
     */
    @Nonnull
    SortedSnowflakeCacheView<ScheduledEvent> getScheduledEventCache();

    /**
     * Retrieves all {@link ScheduledEvent ScheduledEvents} for this guild.
     * <br>This list does not include user count data. Use {@link #retrieveScheduledEvents(boolean)} to get user count data
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link List} of {@link ScheduledEvent}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<List<ScheduledEvent>> retrieveScheduledEvents() {
        return retrieveScheduledEvents(false);
    }

    /**
     * Retrieves all {@link ScheduledEvent ScheduledEvents} for this guild.
     *
     * @param  includeUserCount
     *         Whether to include user counts for the {@link ScheduledEvent ScheduledEvents}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link List} of {@link ScheduledEvent}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<List<ScheduledEvent>> retrieveScheduledEvents(boolean includeUserCount);

    /**
     * Gets a list of all {@link ScheduledEvent ScheduledEvents} in this Guild that have the same
     * name as the one provided.
     * <br>If there are no {@link ScheduledEvent ScheduledEvents} with the provided name,
     * then this returns an empty list.
     *
     * <p>This requires {@link CacheFlag#SCHEDULED_EVENTS} to be enabled.
     *
     * @param  name
     *         The name used to filter the returned {@link ScheduledEvent} objects.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws java.lang.IllegalArgumentException
     *         If the name is blank, empty or {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all ScheduledEvent names that match the provided name.
     */
    @Nonnull
    @Unmodifiable
    default List<ScheduledEvent> getScheduledEventsByName(@Nonnull String name, boolean ignoreCase) {
        return getScheduledEventCache().getElementsByName(name, ignoreCase);
    }

    /**
     * Gets a {@link ScheduledEvent} from this guild that has the same id as the
     * one provided. This method is similar to {@link JDA#getScheduledEventById(String)}, but it only
     * checks this specific Guild for a scheduled event.
     * <br>If there is no {@link ScheduledEvent} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p>This requires {@link CacheFlag#SCHEDULED_EVENTS} to be enabled.
     *
     * @param  id
     *         The id of the {@link ScheduledEvent}.
     *
     * @throws java.lang.NumberFormatException
     *         If the provided {@code id} cannot be parsed by {@link Long#parseLong(String)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link ScheduledEvent} with matching id.
     */
    @Nullable
    default ScheduledEvent getScheduledEventById(@Nonnull String id) {
        return getScheduledEventCache().getElementById(id);
    }

    /**
     * Gets a {@link ScheduledEvent} from this guild that has the same id as the
     * one provided. This method is similar to {@link JDA#getScheduledEventById(long)}, but it only
     * checks this specific Guild for a scheduled event.
     * <br>If there is no {@link ScheduledEvent} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p>This requires {@link CacheFlag#SCHEDULED_EVENTS} to be enabled.
     *
     * @param  id
     *         The id of the {@link ScheduledEvent}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link ScheduledEvent} with matching id.
     */
    @Nullable
    default ScheduledEvent getScheduledEventById(long id) {
        return getScheduledEventCache().getElementById(id);
    }

    /**
     * Gets all {@link ScheduledEvent ScheduledEvents} in this guild.
     * <br>Scheduled events are sorted by their start time, and events that start at the same time
     * are sorted by their snowflake ID.
     *
     * <p>This copies the backing store into a list. This means every call
     * creates a new list with O(n) complexity. It is recommended to store this into
     * a local variable or use {@link #getScheduledEventCache()} and use its more efficient
     * versions of handling these values.
     *
     * <p>This requires {@link CacheFlag#SCHEDULED_EVENTS} to be enabled.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable List of {@link ScheduledEvent ScheduledEvents}.
     */
    @Nonnull
    @Unmodifiable
    default List<ScheduledEvent> getScheduledEvents() {
        return getScheduledEventCache().asList();
    }

    @Nonnull
    @Override
    SortedSnowflakeCacheView<StageChannel> getStageChannelCache();

    @Nonnull
    @Override
    SortedSnowflakeCacheView<ThreadChannel> getThreadChannelCache();

    @Nonnull
    @Override
    SortedSnowflakeCacheView<Category> getCategoryCache();

    @Nonnull
    @Override
    SortedSnowflakeCacheView<TextChannel> getTextChannelCache();

    @Nonnull
    @Override
    SortedSnowflakeCacheView<NewsChannel> getNewsChannelCache();

    @Nonnull
    @Override
    SortedSnowflakeCacheView<VoiceChannel> getVoiceChannelCache();

    @Nonnull
    @Override
    SortedSnowflakeCacheView<ForumChannel> getForumChannelCache();

    /**
     * {@link SortedChannelCacheView SortedChannelCacheView} of {@link GuildChannel}.
     *
     * <p>Provides cache access to all channels of this guild, including thread channels (unlike {@link #getChannels()}).
     * The cache view attempts to provide a sorted list, based on how channels are displayed in the client.
     * Various methods like {@link SortedChannelCacheView#forEachUnordered(Consumer)} or {@link SortedChannelCacheView#lockedIterator()}
     * bypass sorting for optimization reasons.
     *
     * <p>It is possible to filter the channels to more specific types using
     * {@link ChannelCacheView#getElementById(ChannelType, long)} or {@link SortedChannelCacheView#ofType(Class)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link SortedChannelCacheView SortedChannelCacheView}
     */
    @Nonnull
    @Override
    SortedChannelCacheView<GuildChannel> getChannelCache();

    /**
     * Populated list of {@link GuildChannel channels} for this guild.
     * <br>This includes all types of channels, except for threads.
     * <br>This includes hidden channels by default,
     * you can use {@link #getChannels(boolean) getChannels(false)} to exclude hidden channels.
     *
     * <p>The returned list is ordered in the same fashion as it would be by the official discord client.
     * <ol>
     *     <li>TextChannel, ForumChannel, and NewsChannel without parent</li>
     *     <li>VoiceChannel and StageChannel without parent</li>
     *     <li>Categories
     *         <ol>
     *             <li>TextChannel, ForumChannel, and NewsChannel with category as parent</li>
     *             <li>VoiceChannel and StageChannel with category as parent</li>
     *         </ol>
     *     </li>
     * </ol>
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Immutable list of channels for this guild
     *
     * @see    #getChannels(boolean)
     */
    @Nonnull
    @Unmodifiable
    default List<GuildChannel> getChannels() {
        return getChannels(true);
    }

    /**
     * Populated list of {@link GuildChannel channels} for this guild.
     * <br>This includes all types of channels, except for threads.
     *
     * <p>The returned list is ordered in the same fashion as it would be by the official discord client.
     * <ol>
     *     <li>TextChannel, ForumChannel, and NewsChannel without parent</li>
     *     <li>VoiceChannel and StageChannel without parent</li>
     *     <li>Categories
     *         <ol>
     *             <li>TextChannel, ForumChannel, and NewsChannel with category as parent</li>
     *             <li>VoiceChannel and StageChannel with category as parent</li>
     *         </ol>
     *     </li>
     * </ol>
     *
     * @param  includeHidden
     *         Whether to include channels with denied {@link Permission#VIEW_CHANNEL View Channel Permission}
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Immutable list of channels for this guild
     *
     * @see    #getChannels()
     */
    @Nonnull
    @Unmodifiable
    List<GuildChannel> getChannels(boolean includeHidden);

    /**
     * Gets a {@link Role Role} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link Role Role} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * @param  id
     *         The id of the {@link Role Role}.
     *
     * @throws java.lang.NumberFormatException
     *         If the provided {@code id} cannot be parsed by {@link Long#parseLong(String)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link Role Role} with matching id.
     */
    @Nullable
    default Role getRoleById(@Nonnull String id) {
        return getRoleCache().getElementById(id);
    }

    /**
     * Gets a {@link Role Role} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link Role Role} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * @param  id
     *         The id of the {@link Role Role}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-null {@link Role Role} with matching id.
     */
    @Nullable
    default Role getRoleById(long id) {
        return getRoleCache().getElementById(id);
    }

    /**
     * Gets all {@link Role Roles} in this {@link net.dv8tion.jda.api.entities.Guild Guild}.
     * <br>The roles returned will be sorted according to their position. The highest role being at index 0
     * and the lowest at the last index.
     *
     * <p>This copies the backing store into a list. This means every call
     * creates a new list with O(n) complexity. It is recommended to store this into
     * a local variable or use {@link #getRoleCache()} and use its more efficient
     * versions of handling these values.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return An immutable List of {@link Role Roles}.
     */
    @Nonnull
    @Unmodifiable
    default List<Role> getRoles() {
        return getRoleCache().asList();
    }

    /**
     * Gets a list of all {@link Role Roles} in this Guild that have the same
     * name as the one provided.
     * <br>If there are no {@link Role Roles} with the provided name, then this returns an empty list.
     *
     * @param  name
     *         The name used to filter the returned {@link Role Roles}.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all Role names that match the provided name.
     */
    @Nonnull
    @Unmodifiable
    default List<Role> getRolesByName(@Nonnull String name, boolean ignoreCase) {
        return getRoleCache().getElementsByName(name, ignoreCase);
    }

    /**
     * Looks up a role which is the integration role for a bot.
     * <br>These roles are created when the bot requested a list of permission in the authorization URL.
     *
     * <p>To check whether a role is a bot role you can use {@code role.getTags().isBot()} and you can use
     * {@link Role.RoleTags#getBotIdLong()} to check which bot it applies to.
     *
     * <p>This requires {@link net.dv8tion.jda.api.utils.cache.CacheFlag#ROLE_TAGS CacheFlag.ROLE_TAGS} to be enabled.
     * See {@link net.dv8tion.jda.api.JDABuilder#enableCache(CacheFlag, CacheFlag...) JDABuilder.enableCache(...)}.
     *
     * @param  userId
     *         The user id of the bot
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The bot role, or null if no role matches
     */
    @Nullable
    default Role getRoleByBot(long userId) {
        return getRoleCache()
                .applyStream(stream -> stream.filter(role -> role.getTags().getBotIdLong() == userId)
                        .findFirst()
                        .orElse(null));
    }

    /**
     * Looks up a role which is the integration role for a bot.
     * <br>These roles are created when the bot requested a list of permission in the authorization URL.
     *
     * <p>To check whether a role is a bot role you can use {@code role.getTags().isBot()} and you can use
     * {@link Role.RoleTags#getBotIdLong()} to check which bot it applies to.
     *
     * <p>This requires {@link net.dv8tion.jda.api.utils.cache.CacheFlag#ROLE_TAGS CacheFlag.ROLE_TAGS} to be enabled.
     * See {@link net.dv8tion.jda.api.JDABuilder#enableCache(CacheFlag, CacheFlag...) JDABuilder.enableCache(...)}.
     *
     * @param  userId
     *         The user id of the bot
     *
     * @throws IllegalArgumentException
     *         If the userId is null or not a valid snowflake
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The bot role, or null if no role matches
     */
    @Nullable
    default Role getRoleByBot(@Nonnull String userId) {
        return getRoleByBot(MiscUtil.parseSnowflake(userId));
    }

    /**
     * Looks up a role which is the integration role for a bot.
     * <br>These roles are created when the bot requested a list of permission in the authorization URL.
     *
     * <p>To check whether a role is a bot role you can use {@code role.getTags().isBot()} and you can use
     * {@link Role.RoleTags#getBotIdLong()} to check which bot it applies to.
     *
     * <p>This requires {@link net.dv8tion.jda.api.utils.cache.CacheFlag#ROLE_TAGS CacheFlag.ROLE_TAGS} to be enabled.
     * See {@link net.dv8tion.jda.api.JDABuilder#enableCache(CacheFlag, CacheFlag...) JDABuilder.enableCache(...)}.
     *
     * @param  user
     *         The bot user
     *
     * @throws IllegalArgumentException
     *         If null is provided
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The bot role, or null if no role matches
     */
    @Nullable
    default Role getRoleByBot(@Nonnull User user) {
        Checks.notNull(user, "User");
        return getRoleByBot(user.getIdLong());
    }

    /**
     * Looks up the role which is the integration role for the currently connected bot (self-user).
     * <br>These roles are created when the bot requested a list of permission in the authorization URL.
     *
     * <p>To check whether a role is a bot role you can use {@code role.getTags().isBot()} and you can use
     * {@link Role.RoleTags#getBotIdLong()} to check which bot it applies to.
     *
     * <p>This requires {@link net.dv8tion.jda.api.utils.cache.CacheFlag#ROLE_TAGS CacheFlag.ROLE_TAGS} to be enabled.
     * See {@link net.dv8tion.jda.api.JDABuilder#enableCache(CacheFlag, CacheFlag...) JDABuilder.enableCache(...)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The bot role, or null if no role matches
     */
    @Nullable
    default Role getBotRole() {
        return getRoleByBot(getJDA().getSelfUser());
    }

    /**
     * Looks up the role which is the booster role of this guild.
     * <br>These roles are created when the first user boosts this guild.
     *
     * <p>To check whether a role is a booster role you can use {@code role.getTags().isBoost()}.
     *
     * <p>This requires {@link net.dv8tion.jda.api.utils.cache.CacheFlag#ROLE_TAGS CacheFlag.ROLE_TAGS} to be enabled.
     * See {@link net.dv8tion.jda.api.JDABuilder#enableCache(CacheFlag, CacheFlag...) JDABuilder.enableCache(...)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The boost role, or null if no role matches
     */
    @Nullable
    default Role getBoostRole() {
        return getRoleCache()
                .applyStream(stream -> stream.filter(role -> role.getTags().isBoost())
                        .findFirst()
                        .orElse(null));
    }

    /**
     * Sorted {@link net.dv8tion.jda.api.utils.cache.SnowflakeCacheView SnowflakeCacheView} of
     * all cached {@link Role Roles} of this Guild.
     * <br>Roles are sorted according to their position.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.utils.cache.SortedSnowflakeCacheView SortedSnowflakeCacheView}
     */
    @Nonnull
    SortedSnowflakeCacheView<Role> getRoleCache();

    /**
     * Gets a {@link RichCustomEmoji} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link RichCustomEmoji} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p><b>Unicode emojis are not included as {@link RichCustomEmoji}!</b>
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#EMOJI CacheFlag.EMOJI} to be enabled!
     *
     * @param  id
     *         the emoji id
     *
     * @throws java.lang.NumberFormatException
     *         If the provided {@code id} cannot be parsed by {@link Long#parseLong(String)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return An Emoji matching the specified id
     *
     * @see    #retrieveEmojiById(String)
     */
    @Nullable
    default RichCustomEmoji getEmojiById(@Nonnull String id) {
        return getEmojiCache().getElementById(id);
    }

    /**
     * Gets an {@link RichCustomEmoji} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link RichCustomEmoji} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p><b>Unicode emojis are not included as {@link RichCustomEmoji}!</b>
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#EMOJI CacheFlag.EMOJI} to be enabled!
     *
     * @param  id
     *         the emoji id
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return An emoji matching the specified id
     *
     * @see    #retrieveEmojiById(long)
     */
    @Nullable
    default RichCustomEmoji getEmojiById(long id) {
        return getEmojiCache().getElementById(id);
    }

    /**
     * Gets all {@link RichCustomEmoji Custom Emojis} belonging to this {@link net.dv8tion.jda.api.entities.Guild Guild}.
     * <br>Emojis are not ordered in any specific way in the returned list.
     *
     * <p><b>Unicode emojis are not included as {@link RichCustomEmoji}!</b>
     *
     * <p>This copies the backing store into a list. This means every call
     * creates a new list with O(n) complexity. It is recommended to store this into
     * a local variable or use {@link #getEmojiCache()} and use its more efficient
     * versions of handling these values.
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#EMOJI CacheFlag.EMOJI} to be enabled!
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return An immutable List of {@link RichCustomEmoji Custom Emojis}.
     *
     * @see    #retrieveEmojis()
     */
    @Nonnull
    @Unmodifiable
    default List<RichCustomEmoji> getEmojis() {
        return getEmojiCache().asList();
    }

    /**
     * Gets a list of all {@link RichCustomEmoji Custom Emojis} in this Guild that have the same
     * name as the one provided.
     * <br>If there are no {@link RichCustomEmoji Emojis} with the provided name, then this returns an empty list.
     *
     * <p><b>Unicode emojis are not included as {@link RichCustomEmoji}!</b>
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#EMOJI CacheFlag.EMOJI} to be enabled!
     *
     * @param  name
     *         The name used to filter the returned {@link RichCustomEmoji Emojis}. Without colons.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all Emojis that match the provided name.
     */
    @Nonnull
    @Unmodifiable
    default List<RichCustomEmoji> getEmojisByName(@Nonnull String name, boolean ignoreCase) {
        return getEmojiCache().getElementsByName(name, ignoreCase);
    }

    /**
     * {@link net.dv8tion.jda.api.utils.cache.SnowflakeCacheView SnowflakeCacheView} of
     * all cached {@link RichCustomEmoji Custom Emojis} of this Guild.
     * <br>This will be empty if {@link net.dv8tion.jda.api.utils.cache.CacheFlag#EMOJI} is disabled.
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#EMOJI CacheFlag.EMOJI} to be enabled!
     *
     * @return {@link net.dv8tion.jda.api.utils.cache.SnowflakeCacheView SnowflakeCacheView}
     *
     * @see    #retrieveEmojis()
     */
    @Nonnull
    SnowflakeCacheView<RichCustomEmoji> getEmojiCache();

    /**
     * Gets a {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildSticker} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildSticker} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#STICKER CacheFlag.STICKER} to be enabled!
     *
     * @param  id
     *         the sticker id
     *
     * @throws java.lang.NumberFormatException
     *         If the provided {@code id} cannot be parsed by {@link Long#parseLong(String)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A Sticker matching the specified id
     *
     * @see    #retrieveSticker(StickerSnowflake)
     */
    @Nullable
    default GuildSticker getStickerById(@Nonnull String id) {
        return getStickerCache().getElementById(id);
    }

    /**
     * Gets a {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildSticker} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildSticker} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#STICKER CacheFlag.STICKER} to be enabled!
     *
     * @param  id
     *         the sticker id
     *
     * @return A Sticker matching the specified id
     *
     * @see    #retrieveSticker(StickerSnowflake)
     */
    @Nullable
    default GuildSticker getStickerById(long id) {
        return getStickerCache().getElementById(id);
    }

    /**
     * Gets all custom {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildStickers} belonging to this {@link net.dv8tion.jda.api.entities.Guild Guild}.
     * <br>GuildStickers are not ordered in any specific way in the returned list.
     *
     * <p>This copies the backing store into a list. This means every call
     * creates a new list with O(n) complexity. It is recommended to store this into
     * a local variable or use {@link #getStickerCache()} and use its more efficient
     * versions of handling these values.
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#STICKER CacheFlag.STICKER} to be enabled!
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return An immutable List of {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildStickers}.
     *
     * @see    #retrieveStickers()
     */
    @Nonnull
    @Unmodifiable
    default List<GuildSticker> getStickers() {
        return getStickerCache().asList();
    }

    /**
     * Gets a list of all {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildStickers} in this Guild that have the same
     * name as the one provided.
     * <br>If there are no {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildStickers} with the provided name, then this returns an empty list.
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#STICKER CacheFlag.STICKER} to be enabled!
     *
     * @param  name
     *         The name used to filter the returned {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildStickers}. Without colons.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all Stickers that match the provided name.
     */
    @Nonnull
    @Unmodifiable
    default List<GuildSticker> getStickersByName(@Nonnull String name, boolean ignoreCase) {
        return getStickerCache().getElementsByName(name, ignoreCase);
    }

    /**
     * {@link net.dv8tion.jda.api.utils.cache.SnowflakeCacheView SnowflakeCacheView} of
     * all cached {@link net.dv8tion.jda.api.entities.sticker.GuildSticker GuildStickers} of this Guild.
     * <br>This will be empty if {@link net.dv8tion.jda.api.utils.cache.CacheFlag#STICKER} is disabled.
     *
     * <p>This requires the {@link net.dv8tion.jda.api.utils.cache.CacheFlag#STICKER CacheFlag.STICKER} to be enabled!
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.utils.cache.SnowflakeCacheView SnowflakeCacheView}
     *
     * @see    #retrieveStickers()
     */
    @Nonnull
    SnowflakeCacheView<GuildSticker> getStickerCache();

    /**
     * Gets a {@link SoundboardSound} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link SoundboardSound} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p>This requires the {@link CacheFlag#SOUNDBOARD_SOUNDS} to be enabled!
     *
     * @param  id
     *         the soundboard sound id
     *
     * @throws NumberFormatException
     *         If the provided {@code id} cannot be parsed by {@link Long#parseLong(String)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A Soundboard sound matching the specified id
     */
    @Nullable
    default SoundboardSound getSoundboardSoundById(@Nonnull String id) {
        return getSoundboardSoundCache().getElementById(id);
    }

    /**
     * Gets a {@link SoundboardSound} from this guild that has the same id as the
     * one provided.
     * <br>If there is no {@link SoundboardSound} with an id that matches the provided
     * one, then this returns {@code null}.
     *
     * <p>This requires the {@link CacheFlag#SOUNDBOARD_SOUNDS} to be enabled!
     *
     * @param  id
     *         the soundboard sound id
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A Soundboard sound matching the specified id
     */
    @Nullable
    default SoundboardSound getSoundboardSoundById(long id) {
        return getSoundboardSoundCache().getElementById(id);
    }

    /**
     * Gets all custom {@link SoundboardSound SoundboardSounds} belonging to this guild.
     * <br>Soundboard sounds are not ordered in any specific way in the returned list.
     *
     * <p>This copies the backing store into a list. This means every call
     * creates a new list with O(n) complexity. It is recommended to store this into
     * a local variable or use {@link #getSoundboardSoundCache()} and use its more efficient
     * versions of handling these values.
     *
     * <p>This requires the {@link CacheFlag#SOUNDBOARD_SOUNDS} to be enabled!
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return An immutable List of {@link SoundboardSound SoundboardSounds}.
     */
    @Nonnull
    @Unmodifiable
    default List<SoundboardSound> getSoundboardSounds() {
        return getSoundboardSoundCache().asList();
    }

    /**
     * Gets a list of all {@link SoundboardSound SoundboardSounds} in this Guild that have the same
     * name as the one provided.
     * <br>If there are no {@link SoundboardSound SoundboardSounds} with the provided name, then this returns an empty list.
     *
     * <p>This requires the {@link CacheFlag#SOUNDBOARD_SOUNDS} to be enabled!
     *
     * @param  name
     *         The name used to filter the returned {@link SoundboardSound SoundboardSounds}.
     * @param  ignoreCase
     *         Determines if the comparison ignores case when comparing. True - case insensitive.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return Possibly-empty immutable list of all SoundboardSounds that match the provided name.
     */
    @Nonnull
    @Unmodifiable
    default List<SoundboardSound> getSoundboardSoundsByName(@Nonnull String name, boolean ignoreCase) {
        return getSoundboardSoundCache().getElementsByName(name, ignoreCase);
    }

    /**
     * {@link SnowflakeCacheView} of all cached {@link SoundboardSound SoundboardSounds} of this Guild.
     * <br>This does not include {@link JDA#retrieveDefaultSoundboardSounds() default sounds}.
     *
     * <p>This will be empty if {@link CacheFlag#SOUNDBOARD_SOUNDS} is disabled!
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link SnowflakeCacheView} - Type: {@link SoundboardSound}
     *
     * @see    JDA#retrieveDefaultSoundboardSounds()
     */
    @Nonnull
    SnowflakeCacheView<SoundboardSound> getSoundboardSoundCache();

    /**
     * Retrieves an immutable list of Custom Emojis together with their respective creators.
     *
     * <p>Note that {@link RichCustomEmoji#getOwner()} is only available if the currently
     * logged in account has {@link net.dv8tion.jda.api.Permission#MANAGE_GUILD_EXPRESSIONS Permission.MANAGE_GUILD_EXPRESSIONS}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: List of {@link RichCustomEmoji}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<@Unmodifiable List<RichCustomEmoji>> retrieveEmojis();

    /**
     * Retrieves a custom emoji together with its respective creator.
     * <br><b>This does not include unicode emoji.</b>
     *
     * <p>Note that {@link RichCustomEmoji#getOwner()} is only available if the currently
     * logged in account has {@link net.dv8tion.jda.api.Permission#MANAGE_GUILD_EXPRESSIONS Permission.MANAGE_GUILD_EXPRESSIONS}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_EMOJI UNKNOWN_EMOJI}
     *     <br>If the provided id does not correspond to an emoji in this guild</li>
     * </ul>
     *
     * @param  id
     *         The emoji id
     *
     * @throws IllegalArgumentException
     *         If the provided id is not a valid snowflake
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: {@link RichCustomEmoji}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<RichCustomEmoji> retrieveEmojiById(@Nonnull String id);

    /**
     * Retrieves a Custom Emoji together with its respective creator.
     *
     * <p>Note that {@link RichCustomEmoji#getOwner()} is only available if the currently
     * logged in account has {@link net.dv8tion.jda.api.Permission#MANAGE_GUILD_EXPRESSIONS Permission.MANAGE_GUILD_EXPRESSIONS}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_EMOJI UNKNOWN_EMOJI}
     *     <br>If the provided id does not correspond to an emoji in this guild</li>
     * </ul>
     *
     * @param  id
     *         The emoji id
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: {@link RichCustomEmoji}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<RichCustomEmoji> retrieveEmojiById(long id) {
        return retrieveEmojiById(Long.toUnsignedString(id));
    }

    /**
     * Retrieves a custom emoji together with its respective creator.
     *
     * <p>Note that {@link RichCustomEmoji#getOwner()} is only available if the currently
     * logged in account has {@link net.dv8tion.jda.api.Permission#MANAGE_GUILD_EXPRESSIONS Permission.MANAGE_GUILD_EXPRESSIONS}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_EMOJI UNKNOWN_EMOJI}
     *     <br>If the provided emoji does not correspond to an emoji in this guild anymore</li>
     * </ul>
     *
     * @param  emoji
     *         The emoji reference to retrieve
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link RichCustomEmoji}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<RichCustomEmoji> retrieveEmoji(@Nonnull CustomEmoji emoji) {
        Checks.notNull(emoji, "Emoji");
        if (emoji instanceof RichCustomEmoji && ((RichCustomEmoji) emoji).getGuild() != null) {
            Checks.check(((RichCustomEmoji) emoji).getGuild().equals(this), "Emoji must be from the same Guild!");
        }

        JDA jda = getJDA();
        return new DeferredRestAction<>(
                jda,
                RichCustomEmoji.class,
                () -> {
                    if (emoji instanceof RichCustomEmoji) {
                        RichCustomEmoji richEmoji = (RichCustomEmoji) emoji;
                        if (richEmoji.getOwner() != null
                                || !getSelfMember().hasPermission(Permission.MANAGE_GUILD_EXPRESSIONS)) {
                            return richEmoji;
                        }
                    }
                    return null;
                },
                () -> retrieveEmojiById(emoji.getId()));
    }

    /**
     * Retrieves all the stickers from this guild.
     * <br>This also includes {@link GuildSticker#isAvailable() unavailable} stickers.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: List of {@link GuildSticker}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<@Unmodifiable List<GuildSticker>> retrieveStickers();

    /**
     * Attempts to retrieve a {@link GuildSticker} object for this guild based on the provided snowflake reference.
     *
     * <p>The returned {@link net.dv8tion.jda.api.requests.RestAction RestAction} can encounter the following Discord errors:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_STICKER UNKNOWN_STICKER}
     *     <br>Occurs when the provided id does not refer to a sticker known by Discord.</li>
     * </ul>
     *
     * @param  sticker
     *         The reference of the requested {@link Sticker}.
     *         <br>Can be {@link RichSticker}, {@link StickerItem}, or {@link Sticker#fromId(long)}.
     *
     * @throws IllegalArgumentException
     *         If null is provided
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.RestAction RestAction} - Type: {@link GuildSticker}
     *         <br>On request, gets the sticker with id matching provided id from Discord.
     */
    @Nonnull
    @CheckReturnValue
    RestAction<GuildSticker> retrieveSticker(@Nonnull StickerSnowflake sticker);

    /**
     * Modify a sticker using {@link GuildStickerManager}.
     * <br>You can update multiple fields at once, by calling the respective setters before executing the request.
     *
     * <p>The returned {@link net.dv8tion.jda.api.requests.RestAction RestAction} can encounter the following Discord errors:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_STICKER UNKNOWN_STICKER}
     *     <br>Occurs when the provided id does not refer to a sticker known by Discord.</li>
     * </ul>
     *
     * @throws IllegalArgumentException
     *         If null is provided
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link Permission#MANAGE_GUILD_EXPRESSIONS MANAGE_GUILD_EXPRESSIONS}
     *         nor {@link Permission#CREATE_GUILD_EXPRESSIONS CREATE_GUILD_EXPRESSIONS} in the guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link GuildStickerManager}
     */
    @Nonnull
    @CheckReturnValue
    GuildStickerManager editSticker(@Nonnull StickerSnowflake sticker);

    /**
     * Retrieves all the soundboard sounds from this guild.
     * <br>This also includes {@link SoundboardSound#isAvailable() unavailable} soundboard sounds.
     *
     * <p>If {@link CacheFlag#SOUNDBOARD_SOUNDS} is enabled, this action immediately returns the cached sounds.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link CacheRestAction} - Type: List of {@link SoundboardSound}
     */
    @Nonnull
    @CheckReturnValue
    CacheRestAction<List<SoundboardSound>> retrieveSoundboardSounds();

    /**
     * Attempts to retrieve a {@link SoundboardSound} object for this guild based on the provided snowflake reference.
     *
     * <p>If {@link CacheFlag#SOUNDBOARD_SOUNDS} is enabled, this action immediately returns the cached sound.
     *
     * <p>The returned {@link net.dv8tion.jda.api.requests.RestAction RestAction} can encounter the following Discord errors:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_SOUND UNKNOWN_SOUND}
     *     <br>Occurs when the provided id does not refer to a soundboard sound known by Discord.</li>
     * </ul>
     *
     * @param  sound
     *         The reference of the requested {@link SoundboardSound}.
     *
     * @throws IllegalArgumentException
     *         If {@code null} is provided
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link CacheRestAction} - Type: {@link SoundboardSound}
     */
    @Nonnull
    @CheckReturnValue
    CacheRestAction<SoundboardSound> retrieveSoundboardSound(@Nonnull SoundboardSoundSnowflake sound);

    /**
     * Modify a soundboard sound using {@link SoundboardSoundManager}.
     * <br>You can update multiple fields at once, by calling the respective setters before executing the request.
     *
     * <p>The returned {@link net.dv8tion.jda.api.requests.RestAction RestAction} can encounter the following Discord errors:
     * <ul>
     *     <li>{@link ErrorResponse#UNKNOWN_SOUND UNKNOWN_SOUND}
     *     <br>Occurs when the provided id does not refer to a soundboard sound known by Discord.</li>
     *     <li>{@link ErrorResponse#INVALID_EMOJI INVALID_EMOJI}
     *     <br>The emoji is invalid</li>
     *     <li>{@link ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The sound cannot be deleted due to a permission discrepancy</li>
     * </ul>
     *
     * @param  sound
     *         The reference of the {@link SoundboardSound}.
     *
     * @throws IllegalArgumentException
     *         If {@code null} is provided
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link Permission#MANAGE_GUILD_EXPRESSIONS MANAGE_GUILD_EXPRESSIONS} in the guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link SoundboardSoundManager}
     */
    @Nonnull
    @CheckReturnValue
    SoundboardSoundManager editSoundboardSound(@Nonnull SoundboardSoundSnowflake sound);

    /**
     * Retrieves an immutable list of the currently banned {@link net.dv8tion.jda.api.entities.User Users}.
     * <br>If you wish to ban or unban a user, use either {@link #ban(UserSnowflake, int, TimeUnit)} or
     * {@link #unban(UserSnowflake)}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The ban list cannot be fetched due to a permission discrepancy</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#BAN_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The {@link net.dv8tion.jda.api.requests.restaction.pagination.BanPaginationAction BanPaginationAction} of the guild's bans.
     */
    @Nonnull
    @CheckReturnValue
    BanPaginationAction retrieveBanList();

    /**
     * Retrieves a {@link net.dv8tion.jda.api.entities.Guild.Ban Ban} of the provided {@link UserSnowflake}.
     * <br>If you wish to ban or unban a user, use either {@link #ban(UserSnowflake, int, TimeUnit)} or {@link #unban(UserSnowflake)}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The ban list cannot be fetched due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_BAN UNKNOWN_BAN}
     *     <br>Either the ban was removed before finishing the task or it did not exist in the first place</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} for the banned user.
     *         This can be a user instance or {@link User#fromId(long)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#BAN_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: {@link net.dv8tion.jda.api.entities.Guild.Ban Ban}
     *         <br>An unmodifiable ban object for the user banned from this guild
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Ban> retrieveBan(@Nonnull UserSnowflake user);

    /**
     * The method calculates the amount of Members that would be pruned if {@link #prune(int, Role...)} was executed.
     * Prunability is determined by a Member being offline for at least <i>days</i> days.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The prune count cannot be fetched due to a permission discrepancy</li>
     * </ul>
     *
     * @param  days
     *         Minimum number of days since a member has been offline to get affected.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         <ul>
     *             <li>If the server has the {@code PRUNE_REQUIRES_ADMIN} feature enabled,
     *                 and the account doesn't have {@link net.dv8tion.jda.api.Permission#ADMINISTRATOR ADMINISTRATOR} Permission
     *             </li>
     *             <li>If the server <b>does not</b> have the {@code PRUNE_REQUIRES_ADMIN} feature enabled,
     *                 and the account doesn't have {@link net.dv8tion.jda.api.Permission#KICK_MEMBERS KICK_MEMBERS}
     *                 and {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} Permission
     *             </li>
     *         </ul>
     * @throws IllegalArgumentException
     *         If the provided days are less than {@code 1} or more than {@code 30}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: Integer
     *         <br>The amount of Members that would be affected.
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Integer> retrievePrunableMemberCount(int days);

    /**
     * The @everyone {@link Role Role} of this {@link net.dv8tion.jda.api.entities.Guild Guild}.
     * <br>This role is special because its {@link Role#getPosition() position} is calculated as
     * {@code -1}. All other role positions are 0 or greater. This implies that the public role is <b>always</b> below
     * any custom roles created in this Guild. Additionally, all members of this guild are implied to have this role so
     * it is not included in the list returned by {@link Member#getRoles() Member.getRoles()}.
     * <br>The ID of this Role is the Guild's ID thus it is equivalent to using {@link #getRoleById(long) getRoleById(getIdLong())}.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The @everyone {@link Role Role}
     */
    @Nonnull
    Role getPublicRole();

    /**
     * The default {@link StandardGuildChannel} for a {@link net.dv8tion.jda.api.entities.Guild Guild}.
     * <br>This is the channel that the Discord client will default to opening when a Guild is opened for the first time when accepting an invite
     * that is not directed at a specific {@link IInviteContainer channel}.
     *
     * <p>Note: This channel is the first channel in the guild (ordered by position) that the {@link #getPublicRole()}
     * has the {@link net.dv8tion.jda.api.Permission#VIEW_CHANNEL Permission.VIEW_CHANNEL} in.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The {@link StandardGuildChannel channel} representing the default channel for this guild
     */
    @Nullable
    DefaultGuildChannelUnion getDefaultChannel();

    /**
     * Returns the {@link GuildManager GuildManager} for this Guild, used to modify
     * all properties and settings of the Guild.
     * <br>You modify multiple fields in one request by chaining setters before calling {@link RestAction#queue() RestAction.queue()}.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER Permission.MANAGE_SERVER}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The Manager of this Guild
     */
    @Nonnull
    @CheckReturnValue
    GuildManager getManager();

    /**
     * Returns whether this Guild has its boost progress bar shown.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return True, if this Guild has its boost progress bar shown
     */
    boolean isBoostProgressBarEnabled();

    /**
     * A {@link PaginationAction PaginationAction} implementation
     * that allows to {@link Iterable iterate} over all {@link net.dv8tion.jda.api.audit.AuditLogEntry AuditLogEntries} of
     * this Guild.
     * <br>This iterates from the most recent action to the first logged one. (Limit 90 days into history by discord api)
     *
     * <p><b>Examples</b><br>
     * {@snippet lang="java":
     * public void logBan(GuildBanEvent event) {
     *     Guild guild = event.getGuild();
     *     List<TextChannel> modLog = guild.getTextChannelsByName("mod-log", true);
     *     guild.retrieveAuditLogs()
     *          .type(ActionType.BAN) // filter by type
     *          .limit(1)
     *          .queue(list -> {
     *             if (list.isEmpty()) return;
     *             AuditLogEntry entry = list.get(0);
     *             String message = String.format("%#s banned %#s with reason %s",
     *                                            entry.getUser(), event.getUser(), entry.getReason());
     *             modLog.forEach(channel ->
     *               channel.sendMessage(message).queue()
     *             );
     *          });
     * }
     * }
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account
     *         does not have the permission {@link net.dv8tion.jda.api.Permission#VIEW_AUDIT_LOGS VIEW_AUDIT_LOGS}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditLogPaginationAction AuditLogPaginationAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditLogPaginationAction retrieveAuditLogs();

    /**
     * Used to leave a Guild.
     *
     * @throws java.lang.IllegalStateException
     *         Thrown if the currently logged in account is the Owner of this Guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: {@link java.lang.Void}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Void> leave();

    /**
     * The {@link net.dv8tion.jda.api.managers.AudioManager AudioManager} that represents the
     * audio connection for this Guild.
     * <br>If no AudioManager exists for this Guild, this will create a new one.
     * <br>This operation is synchronized on all audio managers for this JDA instance,
     * this means that calling getAudioManager() on any other guild while a thread is accessing this method may be locked.
     *
     * @throws IllegalStateException
     *         If {@link GatewayIntent#GUILD_VOICE_STATES} is disabled
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The AudioManager for this Guild.
     *
     * @see    net.dv8tion.jda.api.JDA#getAudioManagerCache() JDA.getAudioManagerCache()
     */
    @Nonnull
    AudioManager getAudioManager();

    /**
     * Once the currently logged in account is connected to a {@link StageChannel},
     * this will trigger a {@link GuildVoiceState#getRequestToSpeakTimestamp() Request-to-Speak} (aka raise your hand).
     *
     * <p>This will set an internal flag to automatically request to speak once the bot joins a stage channel.
     * <br>You can use {@link #cancelRequestToSpeak()} to move back to the audience or cancel your pending request.
     *
     * <p>If the self member has {@link Permission#VOICE_MUTE_OTHERS} this will immediately promote them to speaker.
     *
     * <p>Example:
     * {@snippet lang="java":
     * stageChannel.createStageInstance("Talent Show").queue()
     * guild.requestToSpeak(); // Set request to speak flag
     * guild.getAudioManager().openAudioConnection(stageChannel); // join the channel
     * }
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} representing the request to speak.
     *         Calling {@link Task#get()} can result in deadlocks and should be avoided at all times.
     *
     * @see    #cancelRequestToSpeak()
     */
    @Nonnull
    Task<Void> requestToSpeak();

    /**
     * Cancels the {@link #requestToSpeak() Request-to-Speak}.
     * <br>This can also be used to move back to the audience if you are currently a speaker.
     *
     * <p>If there is no request to speak or the member is not currently connected to a {@link StageChannel}, this does nothing.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} representing the request to speak cancellation.
     *         Calling {@link Task#get()} can result in deadlocks and should be avoided at all times.
     *
     * @see    #requestToSpeak()
     */
    @Nonnull
    Task<Void> cancelRequestToSpeak();

    /**
     * Returns the {@link net.dv8tion.jda.api.JDA JDA} instance of this Guild
     *
     * @return the corresponding JDA instance
     */
    @Nonnull
    JDA getJDA();

    /**
     * Retrieves all {@link net.dv8tion.jda.api.entities.Invite Invites} for this guild.
     * <br>Requires {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} in this guild.
     * Will throw an {@link net.dv8tion.jda.api.exceptions.InsufficientPermissionException InsufficientPermissionException} otherwise.
     *
     * <p>To get all invites for a {@link GuildChannel GuildChannel}
     * use {@link IInviteContainer#retrieveInvites() GuildChannel.retrieveInvites()}
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         if the account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} in this Guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: List{@literal <}{@link net.dv8tion.jda.api.entities.Invite Invite}{@literal >}
     *         <br>The list of expanded Invite objects
     *
     * @see     IInviteContainer#retrieveInvites()
     */
    @Nonnull
    @CheckReturnValue
    RestAction<@Unmodifiable List<Invite>> retrieveInvites();

    /**
     * Retrieves all {@link net.dv8tion.jda.api.entities.templates.Template Templates} for this guild.
     * <br>Requires {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} in this guild.
     * Will throw an {@link net.dv8tion.jda.api.exceptions.InsufficientPermissionException InsufficientPermissionException} otherwise.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         if the account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} in this Guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: List{@literal <}{@link net.dv8tion.jda.api.entities.templates.Template Template}{@literal >}
     *         <br>The list of Template objects
     */
    @Nonnull
    @CheckReturnValue
    RestAction<@Unmodifiable List<Template>> retrieveTemplates();

    /**
     * Used to create a new {@link net.dv8tion.jda.api.entities.templates.Template Template} for this Guild.
     * <br>Requires {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} in this Guild.
     * Will throw an {@link net.dv8tion.jda.api.exceptions.InsufficientPermissionException InsufficientPermissionException} otherwise.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#ALREADY_HAS_TEMPLATE Guild already has a template}
     *     <br>The guild already has a template.</li>
     * </ul>
     *
     * @param  name
     *         The name of the template
     * @param  description
     *         The description of the template
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         if the account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} in this Guild
     * @throws IllegalArgumentException
     *         If the provided name is {@code null} or not between 1-100 characters long, or
     *         if the provided description is not between 0-120 characters long
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: {@link net.dv8tion.jda.api.entities.templates.Template Template}
     *         <br>The created Template object
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Template> createTemplate(@Nonnull String name, @Nullable String description);

    /**
     * Retrieves all {@link net.dv8tion.jda.api.entities.Webhook Webhooks} for this Guild.
     * <br>Requires {@link net.dv8tion.jda.api.Permission#MANAGE_WEBHOOKS MANAGE_WEBHOOKS} in this Guild.
     *
     * <p>To get all webhooks for a specific {@link TextChannel TextChannel}, use
     * {@link TextChannel#retrieveWebhooks()}
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         if the account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_WEBHOOKS MANAGE_WEBHOOKS} in this Guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction} - Type: List{@literal <}{@link net.dv8tion.jda.api.entities.Webhook Webhook}{@literal >}
     *         <br>A list of all Webhooks in this Guild.
     *
     * @see     TextChannel#retrieveWebhooks()
     */
    @Nonnull
    @CheckReturnValue
    RestAction<@Unmodifiable List<Webhook>> retrieveWebhooks();

    /**
     * Retrieves the {@link GuildWelcomeScreen welcome screen} for this Guild.
     * <br>The welcome screen is shown to all members after joining the Guild.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_GUILD_WELCOME_SCREEN Unknown Guild Welcome Screen}
     *     <br>The guild has no welcome screen</li>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS Missing Permissions}
     *     <br>The guild's welcome screen is disabled
     *     and the currently logged in account doesn't have the {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} permission</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link GuildWelcomeScreen}
     *         <br>The welcome screen for this Guild.
     */
    @Nonnull
    @CheckReturnValue
    RestAction<GuildWelcomeScreen> retrieveWelcomeScreen();

    /**
     * A list containing the cached {@link GuildVoiceState} of every {@link Member}
     * connected to an audio channel in this guild.
     *
     * <p>This requires {@link CacheFlag#VOICE_STATE} to be enabled.
     *
     * @return Immutable list containing all cached {@link GuildVoiceState GuildVoiceStates} for this guild.
     */
    @Nonnull
    @Unmodifiable
    List<GuildVoiceState> getVoiceStates();

    /**
     * Load the member's voice state for the specified user.
     *
     * <p>Possible {@link net.dv8tion.jda.api.exceptions.ErrorResponseException ErrorResponseExceptions} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_VOICE_STATE}
     *     <br>The specified user does not exist, is not a member of this guild or is not connected to a voice channel</li>
     * </ul>
     *
     * @param  id
     *         The user id to load the voice state from
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link GuildVoiceState}
     */
    @Nonnull
    @CheckReturnValue
    CacheRestAction<GuildVoiceState> retrieveMemberVoiceStateById(long id);

    /**
     * Load the member's voice state for the specified user.
     *
     * <p>Possible {@link net.dv8tion.jda.api.exceptions.ErrorResponseException ErrorResponseExceptions} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_VOICE_STATE}
     *     <br>The specified user does not exist, is not a member of this guild or is not connected to a voice channel</li>
     * </ul>
     *
     * @param  id
     *         The user id to load the voice state from
     *
     * @throws IllegalArgumentException
     *         If the provided id is empty or null
     * @throws NumberFormatException
     *         If the provided id is not a snowflake
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link GuildVoiceState}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<GuildVoiceState> retrieveMemberVoiceStateById(@Nonnull String id) {
        return retrieveMemberVoiceStateById(MiscUtil.parseSnowflake(id));
    }

    /**
     * Load the member's voice state for the specified {@link UserSnowflake}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.exceptions.ErrorResponseException ErrorResponseExceptions} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_VOICE_STATE}
     *     <br>The specified user does not exist, is not a member of this guild or is not connected to a voice channel</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} for the member's voice state to retrieve.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     *
     * @throws IllegalArgumentException
     *         If provided with null
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link GuildVoiceState}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<GuildVoiceState> retrieveMemberVoiceState(@Nonnull UserSnowflake user) {
        Checks.notNull(user, "User");
        return retrieveMemberVoiceStateById(user.getIdLong());
    }

    /**
     * Returns the verification-Level of this Guild. Verification level is one of the factors that determines if a Member
     * can send messages in a Guild.
     * <br>For a short description of the different values, see {@link net.dv8tion.jda.api.entities.Guild.VerificationLevel}.
     * <p>
     * This value can be modified using {@link GuildManager#setVerificationLevel(net.dv8tion.jda.api.entities.Guild.VerificationLevel)}.
     *
     * @return The Verification-Level of this Guild.
     */
    @Nonnull
    VerificationLevel getVerificationLevel();

    /**
     * Returns the default message Notification-Level of this Guild. Notification level determines when Members get notification
     * for messages. The value returned is the default level set for any new Members that join the Guild.
     * <br>For a short description of the different values, see {@link net.dv8tion.jda.api.entities.Guild.NotificationLevel NotificationLevel}.
     * <p>
     * This value can be modified using {@link GuildManager#setDefaultNotificationLevel(net.dv8tion.jda.api.entities.Guild.NotificationLevel)}.
     *
     * @return The default message Notification-Level of this Guild.
     */
    @Nonnull
    NotificationLevel getDefaultNotificationLevel();

    /**
     * Returns the level of multifactor authentication required to execute administrator restricted functions in this guild.
     * <br>For a short description of the different values, see {@link net.dv8tion.jda.api.entities.Guild.MFALevel MFALevel}.
     *
     * @return The MFA-Level required by this Guild.
     */
    @Nonnull
    MFALevel getRequiredMFALevel();

    /**
     * The level of content filtering enabled in this Guild.
     * <br>This decides which messages sent by which Members will be scanned for explicit content.
     *
     * @return {@link net.dv8tion.jda.api.entities.Guild.ExplicitContentLevel ExplicitContentLevel} for this Guild
     */
    @Nonnull
    ExplicitContentLevel getExplicitContentLevel();

    /**
     * Retrieves and collects members of this guild into a list.
     * <br>This will use the configured {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     * to decide which members to retain in cache.
     *
     * <p>You can use {@link #findMembers(Predicate)} to filter specific members.
     *
     * <p><b>This requires the privileged GatewayIntent.GUILD_MEMBERS to be enabled!</b>
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @throws IllegalStateException
     *         If the {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS} is not enabled
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} - Type: {@link List} of {@link Member}
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> loadMembers() {
        return findMembers((m) -> true);
    }

    /**
     * Retrieves and collects members of this guild into a list.
     * <br>This will use the configured {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     * to decide which members to retain in cache.
     *
     * <p><b>This requires the privileged GatewayIntent.GUILD_MEMBERS to be enabled!</b>
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  filter
     *         Filter to decide which members to include
     *
     * @throws IllegalArgumentException
     *         If the provided filter is null
     * @throws IllegalStateException
     *         If the {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS} is not enabled
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} - Type: {@link List} of {@link Member}
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> findMembers(@Nonnull Predicate<? super Member> filter) {
        Checks.notNull(filter, "Filter");
        List<Member> list = new ArrayList<>();
        CompletableFuture<List<Member>> future = new CompletableFuture<>();
        Task<Void> reference = loadMembers((member) -> {
            if (filter.test(member)) {
                list.add(member);
            }
        });
        GatewayTask<List<Member>> task = new GatewayTask<>(future, reference::cancel)
                .onSetTimeout(timeout -> reference.setTimeout(Duration.ofMillis(timeout)));
        reference.onSuccess(it -> future.complete(list)).onError(future::completeExceptionally);
        return task;
    }

    /**
     * Retrieves and collects members of this guild into a list.
     * <br>This will use the configured {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     * to decide which members to retain in cache.
     *
     * <p><b>This requires the privileged GatewayIntent.GUILD_MEMBERS to be enabled!</b>
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  roles
     *         Collection of all roles the members must have
     *
     * @throws IllegalArgumentException
     *         If null is provided
     * @throws IllegalStateException
     *         If the {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS} is not enabled
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} - Type: {@link List} of {@link Member}
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> findMembersWithRoles(@Nonnull Collection<Role> roles) {
        Checks.noneNull(roles, "Roles");
        for (Role role : roles) {
            Checks.check(this.equals(role.getGuild()), "All roles must be from the same guild!");
        }

        if (isLoaded()) {
            CompletableFuture<List<Member>> future = CompletableFuture.completedFuture(getMembersWithRoles(roles));
            return new GatewayTask<>(future, () -> {});
        }

        List<Role> rolesWithoutPublicRole =
                roles.stream().filter(role -> !role.isPublicRole()).collect(Collectors.toList());
        if (rolesWithoutPublicRole.isEmpty()) {
            return loadMembers();
        }

        return findMembers(member -> member.getUnsortedRoles().containsAll(rolesWithoutPublicRole));
    }

    /**
     * Retrieves and collects members of this guild into a list.
     * <br>This will use the configured {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     * to decide which members to retain in cache.
     *
     * <p><b>This requires the privileged GatewayIntent.GUILD_MEMBERS to be enabled!</b>
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  roles
     *         All roles the members must have
     *
     * @throws IllegalArgumentException
     *         If null is provided
     * @throws IllegalStateException
     *         If the {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS} is not enabled
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} - Type: {@link List} of {@link Member}
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> findMembersWithRoles(@Nonnull Role... roles) {
        Checks.noneNull(roles, "Roles");
        return findMembersWithRoles(Arrays.asList(roles));
    }

    /**
     * Retrieves all members of this guild.
     * <br>This will use the configured {@link net.dv8tion.jda.api.utils.MemberCachePolicy MemberCachePolicy}
     * to decide which members to retain in cache.
     *
     * <p><b>This requires the privileged GatewayIntent.GUILD_MEMBERS to be enabled!</b>
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  callback
     *         Consumer callback for each member
     *
     * @throws IllegalArgumentException
     *         If the callback is null
     * @throws IllegalStateException
     *         If the {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS} is not enabled
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} cancellable handle for this request
     */
    @Nonnull
    Task<Void> loadMembers(@Nonnull Consumer<Member> callback);

    /**
     * Load the member for the specified {@link UserSnowflake}.
     * <br>If the member is already loaded it will be retrieved from {@link #getMemberById(long)}
     * and immediately provided if the member information is consistent. The cache consistency directly
     * relies on the enabled {@link GatewayIntent GatewayIntents} as {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS}
     * is required to keep the cache updated with the latest information. You can use {@link CacheRestAction#useCache(boolean) useCache(false)} to always
     * make a new request, which is the default behavior if the required intents are disabled.
     *
     * <p>Possible {@link net.dv8tion.jda.api.exceptions.ErrorResponseException ErrorResponseExceptions} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER}
     *     <br>The specified user is not a member of this guild</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_USER}
     *     <br>The specified user does not exist</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} for the member to retrieve.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     *
     * @throws IllegalArgumentException
     *         If provided with null
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link Member}
     *
     * @see    #pruneMemberCache()
     * @see    #unloadMember(long)
     */
    @Nonnull
    @CheckReturnValue
    default CacheRestAction<Member> retrieveMember(@Nonnull UserSnowflake user) {
        Checks.notNull(user, "User");
        return retrieveMemberById(user.getId());
    }

    /**
     * Shortcut for {@code guild.retrieveMemberById(guild.getOwnerIdLong())}.
     * <br>This will retrieve the current owner of the guild.
     * It is possible that the owner of a guild is no longer a registered discord user in which case this will fail.
     * <br>If the member is already loaded it will be retrieved from {@link #getMemberById(long)}
     * and immediately provided if the member information is consistent. The cache consistency directly
     * relies on the enabled {@link GatewayIntent GatewayIntents} as {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS}
     * is required to keep the cache updated with the latest information. You can use {@link CacheRestAction#useCache(boolean) useCache(false)} to always
     * make a new request, which is the default behavior if the required intents are disabled.
     *
     * <p>Possible {@link net.dv8tion.jda.api.exceptions.ErrorResponseException ErrorResponseExceptions} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER}
     *     <br>The specified user is not a member of this guild</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_USER}
     *     <br>The specified user does not exist</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link Member}
     *
     * @see    #pruneMemberCache()
     * @see    #unloadMember(long)
     * @see    #getOwner()
     * @see    #getOwnerIdLong()
     * @see    #retrieveMemberById(long)
     */
    @Nonnull
    @CheckReturnValue
    default CacheRestAction<Member> retrieveOwner() {
        return retrieveMemberById(getOwnerIdLong());
    }

    /**
     * Load the member for the specified user.
     * <br>If the member is already loaded it will be retrieved from {@link #getMemberById(long)}
     * and immediately provided if the member information is consistent. The cache consistency directly
     * relies on the enabled {@link GatewayIntent GatewayIntents} as {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS}
     * is required to keep the cache updated with the latest information. You can use {@link CacheRestAction#useCache(boolean) useCache(false)} to always
     * make a new request, which is the default behavior if the required intents are disabled.
     *
     * <p>Possible {@link net.dv8tion.jda.api.exceptions.ErrorResponseException ErrorResponseExceptions} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER}
     *     <br>The specified user is not a member of this guild</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_USER}
     *     <br>The specified user does not exist</li>
     * </ul>
     *
     * @param  id
     *         The user id to load the member from
     *
     * @throws IllegalArgumentException
     *         If the provided id is empty or null
     * @throws NumberFormatException
     *         If the provided id is not a snowflake
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link Member}
     *
     * @see    #pruneMemberCache()
     * @see    #unloadMember(long)
     */
    @Nonnull
    @CheckReturnValue
    default CacheRestAction<Member> retrieveMemberById(@Nonnull String id) {
        return retrieveMemberById(MiscUtil.parseSnowflake(id));
    }

    /**
     * Load the member for the specified user.
     * <br>If the member is already loaded it will be retrieved from {@link #getMemberById(long)}
     * and immediately provided if the member information is consistent. The cache consistency directly
     * relies on the enabled {@link GatewayIntent GatewayIntents} as {@link GatewayIntent#GUILD_MEMBERS GatewayIntent.GUILD_MEMBERS}
     * is required to keep the cache updated with the latest information. You can use {@link CacheRestAction#useCache(boolean) useCache(false)} to always
     * make a new request, which is the default behavior if the required intents are disabled.
     *
     * <p>Possible {@link net.dv8tion.jda.api.exceptions.ErrorResponseException ErrorResponseExceptions} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER}
     *     <br>The specified user is not a member of this guild</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_USER}
     *     <br>The specified user does not exist</li>
     * </ul>
     *
     * @param  id
     *         The user id to load the member from
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link Member}
     *
     * @see    #pruneMemberCache()
     * @see    #unloadMember(long)
     */
    @Nonnull
    @CheckReturnValue
    CacheRestAction<Member> retrieveMemberById(long id);

    /**
     * Retrieves a list of members.
     * <br>If the user does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the users resolve to a member, in which case an empty list will be the result.
     *
     * <p>If the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent is enabled,
     * this will load the {@link net.dv8tion.jda.api.OnlineStatus OnlineStatus} and {@link Activity Activities}
     * of the members. You can use {@link #retrieveMembers(boolean, Collection)} to disable presences.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  users
     *         The users of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 IDs</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> retrieveMembers(@Nonnull Collection<? extends UserSnowflake> users) {
        Checks.noneNull(users, "Users");
        if (users.isEmpty()) {
            return new GatewayTask<>(CompletableFuture.completedFuture(Collections.emptyList()), () -> {});
        }

        long[] ids = users.stream().mapToLong(UserSnowflake::getIdLong).toArray();
        return retrieveMembersByIds(ids);
    }

    /**
     * Retrieves a list of members by their user id.
     * <br>If the id does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the IDs resolve to a member, in which case an empty list will be the result.
     *
     * <p>If the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent is enabled,
     * this will load the {@link net.dv8tion.jda.api.OnlineStatus OnlineStatus} and {@link Activity Activities}
     * of the members. You can use {@link #retrieveMembersByIds(boolean, Collection)} to disable presences.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  ids
     *         The ids of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 IDs</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> retrieveMembersByIds(@Nonnull Collection<Long> ids) {
        Checks.noneNull(ids, "IDs");
        if (ids.isEmpty()) {
            return new GatewayTask<>(CompletableFuture.completedFuture(Collections.emptyList()), () -> {});
        }

        long[] arr = ids.stream().mapToLong(Long::longValue).toArray();
        return retrieveMembersByIds(arr);
    }

    /**
     * Retrieves a list of members by their user id.
     * <br>If the id does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the IDs resolve to a member, in which case an empty list will be the result.
     *
     * <p>If the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent is enabled,
     * this will load the {@link net.dv8tion.jda.api.OnlineStatus OnlineStatus} and {@link Activity Activities}
     * of the members. You can use {@link #retrieveMembersByIds(boolean, String...)} to disable presences.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  ids
     *         The ids of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 IDs</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> retrieveMembersByIds(@Nonnull String... ids) {
        Checks.notNull(ids, "Array");
        if (ids.length == 0) {
            return new GatewayTask<>(CompletableFuture.completedFuture(Collections.emptyList()), () -> {});
        }

        long[] arr = new long[ids.length];
        for (int i = 0; i < ids.length; i++) {
            arr[i] = MiscUtil.parseSnowflake(ids[i]);
        }
        return retrieveMembersByIds(arr);
    }

    /**
     * Retrieves a list of members by their user id.
     * <br>If the id does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the IDs resolve to a member, in which case an empty list will be the result.
     *
     * <p>If the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent is enabled,
     * this will load the {@link net.dv8tion.jda.api.OnlineStatus OnlineStatus} and {@link Activity Activities}
     * of the members. You can use {@link #retrieveMembersByIds(boolean, long...)} to disable presences.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  ids
     *         The ids of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 IDs</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> retrieveMembersByIds(@Nonnull long... ids) {
        boolean presence = getJDA().getGatewayIntents().contains(GatewayIntent.GUILD_PRESENCES);
        return retrieveMembersByIds(presence, ids);
    }

    /**
     * Retrieves a list of members.
     * <br>If the user does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the users resolve to a member, in which case an empty list will be the result.
     *
     * <p>You can only load presences with the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent enabled.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  includePresence
     *         Whether to load presences of the members (online status/activity)
     * @param  users
     *         The users of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If includePresence is {@code true} and the GUILD_PRESENCES intent is disabled</li>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 users</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> retrieveMembers(
            boolean includePresence, @Nonnull Collection<? extends UserSnowflake> users) {
        Checks.noneNull(users, "Users");
        if (users.isEmpty()) {
            return new GatewayTask<>(CompletableFuture.completedFuture(Collections.emptyList()), () -> {});
        }

        long[] ids = users.stream().mapToLong(UserSnowflake::getIdLong).toArray();
        return retrieveMembersByIds(includePresence, ids);
    }

    /**
     * Retrieves a list of members by their user id.
     * <br>If the id does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the IDs resolve to a member, in which case an empty list will be the result.
     *
     * <p>You can only load presences with the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent enabled.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  includePresence
     *         Whether to load presences of the members (online status/activity)
     * @param  ids
     *         The ids of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If includePresence is {@code true} and the GUILD_PRESENCES intent is disabled</li>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 IDs</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> retrieveMembersByIds(boolean includePresence, @Nonnull Collection<Long> ids) {
        Checks.noneNull(ids, "IDs");
        if (ids.isEmpty()) {
            return new GatewayTask<>(CompletableFuture.completedFuture(Collections.emptyList()), () -> {});
        }

        long[] arr = ids.stream().mapToLong(Long::longValue).toArray();
        return retrieveMembersByIds(includePresence, arr);
    }

    /**
     * Retrieves a list of members by their user id.
     * <br>If the id does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the IDs resolve to a member, in which case an empty list will be the result.
     *
     * <p>You can only load presences with the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent enabled.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  includePresence
     *         Whether to load presences of the members (online status/activity)
     * @param  ids
     *         The ids of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If includePresence is {@code true} and the GUILD_PRESENCES intent is disabled</li>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 IDs</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    default Task<List<Member>> retrieveMembersByIds(boolean includePresence, @Nonnull String... ids) {
        Checks.notNull(ids, "Array");
        if (ids.length == 0) {
            return new GatewayTask<>(CompletableFuture.completedFuture(Collections.emptyList()), () -> {});
        }

        long[] arr = new long[ids.length];
        for (int i = 0; i < ids.length; i++) {
            arr[i] = MiscUtil.parseSnowflake(ids[i]);
        }
        return retrieveMembersByIds(includePresence, arr);
    }

    /**
     * Retrieves a list of members by their user id.
     * <br>If the id does not resolve to a member of this guild, then it will not appear in the resulting list.
     * It is possible that none of the IDs resolve to a member, in which case an empty list will be the result.
     *
     * <p>You can only load presences with the {@link GatewayIntent#GUILD_PRESENCES GUILD_PRESENCES} intent enabled.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  includePresence
     *         Whether to load presences of the members (online status/activity)
     * @param  ids
     *         The ids of the members (max 100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If includePresence is {@code true} and the GUILD_PRESENCES intent is disabled</li>
     *             <li>If the input contains null</li>
     *             <li>If the input is more than 100 IDs</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     */
    @Nonnull
    @CheckReturnValue
    Task<List<Member>> retrieveMembersByIds(boolean includePresence, @Nonnull long... ids);

    /**
     * Queries a list of members using a radix tree based on the provided name prefix.
     * <br>This will check both the username and the nickname of the members.
     * Additional filtering may be required. If no members with the specified prefix exist, the list will be empty.
     *
     * <p>The requests automatically timeout after {@code 10} seconds.
     * When the timeout occurs a {@link java.util.concurrent.TimeoutException TimeoutException} will be used to complete exceptionally.
     *
     * <p><b>You MUST NOT use blocking operations such as {@link Task#get()}!</b>
     * The response handling happens on the event thread by default.
     *
     * @param  prefix
     *         The case-insensitive name prefix
     * @param  limit
     *         The max amount of members to retrieve (1-100)
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the provided prefix is null or empty.</li>
     *             <li>If the provided limit is not in the range of [1, 100]</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link Task} handle for the request
     *
     * @see    #getMembersByName(String, boolean)
     * @see    #getMembersByNickname(String, boolean)
     * @see    #getMembersByEffectiveName(String, boolean)
     */
    @Nonnull
    @CheckReturnValue
    Task<List<Member>> retrieveMembersByPrefix(@Nonnull String prefix, int limit);

    /**
     * Retrieves the active threads in this guild.
     *
     * @return {@link RestAction} - List of {@link ThreadChannel}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<@Unmodifiable List<ThreadChannel>> retrieveActiveThreads();

    /**
     * Retrieves a {@link ScheduledEvent} by its ID.
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_SCHEDULED_EVENT ErrorResponse.UNKNOWN_SCHEDULED_EVENT}
     *     <br>A scheduled event with the specified ID does not exist in the guild, or the currently logged in user does not
     *     have access to it.</li>
     * </ul>
     *
     * @param  id
     *         The ID of the {@link ScheduledEvent}
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link ScheduledEvent}
     *
     * @see    #getScheduledEventById(long)
     */
    @Nonnull
    @CheckReturnValue
    default CacheRestAction<ScheduledEvent> retrieveScheduledEventById(long id) {
        return retrieveScheduledEventById(Long.toUnsignedString(id));
    }

    /**
     * Retrieves a {@link ScheduledEvent} by its ID.
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_SCHEDULED_EVENT ErrorResponse.UNKNOWN_SCHEDULED_EVENT}
     *     <br>A scheduled event with the specified ID does not exist in this guild, or the currently logged in user does not
     *     have access to it.</li>
     * </ul>
     *
     * @param  id
     *         The ID of the {@link ScheduledEvent}
     *
     * @throws IllegalArgumentException
     *         If the specified ID is {@code null} or empty
     * @throws NumberFormatException
     *         If the specified ID cannot be parsed by {@link Long#parseLong(String)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction} - Type: {@link ScheduledEvent}
     *
     * @see    #getScheduledEventById(long)
     */
    @Nonnull
    @CheckReturnValue
    CacheRestAction<ScheduledEvent> retrieveScheduledEventById(@Nonnull String id);

    /* From GuildController */

    /**
     * Used to move a Member from one {@link AudioChannel AudioChannel}
     * to another {@link AudioChannel AudioChannel}.
     * <br>As a note, you cannot move a Member that isn't already in a AudioChannel. Also they must be in a AudioChannel
     * in the same Guild as the one that you are moving them to.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be moved due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The {@link net.dv8tion.jda.api.Permission#VIEW_CHANNEL VIEW_CHANNEL} permission was removed</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_CHANNEL UNKNOWN_CHANNEL}
     *     <br>The specified channel was deleted before finishing the task</li>
     * </ul>
     *
     * @param  user
     *         The member that you are moving.
     * @param  audioChannel
     *         The destination {@link AudioChannel AudioChannel} to which the member is being
     *         moved to. Or null to perform a voice kick.
     *
     * @throws IllegalStateException
     *         If the user is a Member and isn't currently in a AudioChannel in this Guild, or {@link net.dv8tion.jda.api.utils.cache.CacheFlag#VOICE_STATE} is disabled.
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the provided user is {@code null}</li>
     *             <li>If the provided Member isn't part of this {@link net.dv8tion.jda.api.entities.Guild Guild}</li>
     *             <li>If the provided AudioChannel isn't part of this {@link net.dv8tion.jda.api.entities.Guild Guild}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         <ul>
     *             <li>If this account doesn't have {@link net.dv8tion.jda.api.Permission#VOICE_MOVE_OTHERS}
     *                 in the AudioChannel that the Member is currently in.</li>
     *             <li>If this account <b>AND</b> the Member being moved don't have
     *                 {@link net.dv8tion.jda.api.Permission#VOICE_CONNECT} for the destination AudioChannel.</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction}
     */
    @Nonnull
    @CheckReturnValue
    RestAction<Void> moveVoiceMember(@Nonnull UserSnowflake user, @Nullable AudioChannel audioChannel);

    /**
     * Used to kick a member from a {@link AudioChannel AudioChannel}.
     * <br>As a note, you cannot kick a Member that isn't already in a AudioChannel. Also they must be in a AudioChannel
     * in the same Guild.
     *
     * <p>Equivalent to {@code moveVoiceMember(member, null)}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be moved due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_CHANNEL UNKNOWN_CHANNEL}
     *     <br>The specified channel was deleted before finishing the task</li>
     * </ul>
     *
     * @param  user
     *         The member that you are kicking.
     *
     * @throws IllegalStateException
     *         If the user is a Member and isn't currently in a AudioChannel in this Guild, or {@link net.dv8tion.jda.api.utils.cache.CacheFlag#VOICE_STATE} is disabled.
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If any of the provided arguments is {@code null}</li>
     *             <li>If the provided Member isn't part of this {@link net.dv8tion.jda.api.entities.Guild Guild}</li>
     *             <li>If the provided AudioChannel isn't part of this {@link net.dv8tion.jda.api.entities.Guild Guild}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If this account doesn't have {@link net.dv8tion.jda.api.Permission#VOICE_MOVE_OTHERS}
     *         in the AudioChannel that the Member is currently in.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RestAction RestAction}
     */
    @Nonnull
    @CheckReturnValue
    default RestAction<Void> kickVoiceMember(@Nonnull UserSnowflake user) {
        return moveVoiceMember(user, null);
    }

    /**
     * Changes the Member's nickname in this guild.
     * The nickname is visible to all members of this guild.
     *
     * <p>To change the nickname for the currently logged in account
     * only the Permission {@link net.dv8tion.jda.api.Permission#NICKNAME_CHANGE NICKNAME_CHANGE} is required.
     * <br>To change the nickname of <b>any</b> {@link Member Member} for this {@link net.dv8tion.jda.api.entities.Guild Guild}
     * the Permission {@link net.dv8tion.jda.api.Permission#NICKNAME_MANAGE NICKNAME_MANAGE} is required.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The nickname of the target Member is not modifiable due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * @param  member
     *         The {@link Member Member} for which the nickname should be changed.
     * @param  nickname
     *         The new nickname of the {@link Member Member}, max {@value Member#MAX_NICKNAME_LENGTH} characters in length,
     *         provide {@code null} or an empty String to reset the nickname
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the specified {@link Member} is {@code null}</li>
     *             <li>If the specified {@link Member} is not from the same {@link Guild}</li>
     *             <li>If the new nickname is more than {@value Member#MAX_NICKNAME_LENGTH} characters in length</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         <ul>
     *             <li>If attempting to set nickname for self and the logged in account has neither {@link net.dv8tion.jda.api.Permission#NICKNAME_CHANGE}
     *                 or {@link net.dv8tion.jda.api.Permission#NICKNAME_MANAGE}</li>
     *             <li>If attempting to set nickname for another member and the logged in account does not have {@link net.dv8tion.jda.api.Permission#NICKNAME_MANAGE}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If attempting to set nickname for another member and the logged in account cannot manipulate the other user due to permission hierarchy position.
     *         <br>See {@link Member#canInteract(Member)}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> modifyNickname(@Nonnull Member member, @Nullable String nickname);

    /**
     * This method will prune (kick) all members who were offline for at least <i>days</i> days.
     * <br>The RestAction returned from this method will return the amount of Members that were pruned.
     * <br>You can use {@link Guild#retrievePrunableMemberCount(int)} to determine how many Members would be pruned if you were to
     * call this method.
     *
     * <p>This might timeout when pruning many members.
     * You can use {@code prune(days, false)} to ignore the prune count and avoid a timeout.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The prune cannot be finished due to a permission discrepancy</li>
     * </ul>
     *
     * @param  days
     *         Minimum number of days since a member has been offline to get affected.
     * @param  roles
     *         Optional roles to include in prune filter
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         <ul>
     *             <li>If the server has the {@code PRUNE_REQUIRES_ADMIN} feature enabled,
     *                 and the account doesn't have {@link net.dv8tion.jda.api.Permission#ADMINISTRATOR ADMINISTRATOR} Permission
     *             </li>
     *             <li>If the server <b>does not</b> have the {@code PRUNE_REQUIRES_ADMIN} feature enabled,
     *                 and the account doesn't have {@link net.dv8tion.jda.api.Permission#KICK_MEMBERS KICK_MEMBERS}
     *                 and {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} Permission
     *             </li>
     *         </ul>
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the provided days are not in the range from 1 to 30 (inclusive)</li>
     *             <li>If null is provided</li>
     *             <li>If any of the provided roles is not from this guild</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction} - Type: Integer
     *         <br>The amount of Members that were pruned from the Guild.
     */
    @Nonnull
    @CheckReturnValue
    default AuditableRestAction<Integer> prune(int days, @Nonnull Role... roles) {
        return prune(days, true, roles);
    }

    /**
     * This method will prune (kick) all members who were offline for at least <i>days</i> days.
     * <br>The RestAction returned from this method will return the amount of Members that were pruned.
     * <br>You can use {@link Guild#retrievePrunableMemberCount(int)} to determine how many Members would be pruned if you were to
     * call this method.
     *
     * <p>This might timeout when pruning many members with {@code wait=true}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The prune cannot be finished due to a permission discrepancy</li>
     * </ul>
     *
     * @param  days
     *         Minimum number of days since a member has been offline to get affected.
     * @param  wait
     *         Whether to calculate the number of pruned members and wait for the response (timeout for too many pruned)
     * @param  roles
     *         Optional roles to include in prune filter
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         <ul>
     *             <li>If the server has the {@code PRUNE_REQUIRES_ADMIN} feature enabled,
     *                 and the account doesn't have {@link net.dv8tion.jda.api.Permission#ADMINISTRATOR ADMINISTRATOR} Permission
     *             </li>
     *             <li>If the server <b>does not</b> have the {@code PRUNE_REQUIRES_ADMIN} feature enabled,
     *                 and the account doesn't have {@link net.dv8tion.jda.api.Permission#KICK_MEMBERS KICK_MEMBERS}
     *                 and {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} Permission
     *             </li>
     *         </ul>
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the provided days are not in the range from 1 to 30 (inclusive)</li>
     *             <li>If null is provided</li>
     *             <li>If any of the provided roles is not from this guild</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction} - Type: Integer
     *         <br>Provides the amount of Members that were pruned from the Guild, if wait is true.
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Integer> prune(int days, boolean wait, @Nonnull Role... roles);

    /**
     * Update the current guild {@link SecurityIncidentActions security incident actions}.
     * <br>Security incident actions are used to temporarily disable features for the purpose of moderation.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVALID_FORM_BODY}
     *     <br>If one of the provided timestamps is too far into the future</li>
     * </ul>
     *
     * @param  incidents
     *         The new security incidents
     *
     * @throws IllegalArgumentException
     *         If null is provided
     * @throws InsufficientPermissionException
     *         If the account doesn't have {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER MANAGE_SERVER} Permission.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction}
     *
     * @see    SecurityIncidentActions#enabled(OffsetDateTime, OffsetDateTime)
     * @see    SecurityIncidentActions#disabled()
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> modifySecurityIncidents(@Nonnull SecurityIncidentActions incidents);

    /**
     * Kicks a {@link Member Member} from the {@link net.dv8tion.jda.api.entities.Guild Guild}.
     *
     * <p><b>Note:</b> {@link net.dv8tion.jda.api.entities.Guild#getMembers()} will still contain the {@link net.dv8tion.jda.api.entities.User User}
     * until Discord sends the {@link net.dv8tion.jda.api.events.guild.member.GuildMemberRemoveEvent GuildMemberRemoveEvent}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be kicked due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} for the user to kick.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     *
     * @throws java.lang.IllegalArgumentException
     *         If the user cannot be kicked from this Guild or the provided {@code user} is null.
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#KICK_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the logged in account cannot kick the other member due to permission hierarchy position. (See {@link Member#canInteract(Member)})
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     *         Kicks the provided Member from the current Guild
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> kick(@Nonnull UserSnowflake user);

    /**
     * Bans the user specified by the provided {@link UserSnowflake} and deletes messages sent by the user based on the {@code deletionTimeframe}.
     * <br>If you wish to ban a user without deleting any messages, provide {@code deletionTimeframe} with a value of 0.
     * To set a ban reason, use {@link AuditableRestAction#reason(String)}.
     *
     * <p>You can unban a user with {@link net.dv8tion.jda.api.entities.Guild#unban(UserSnowflake) Guild.unban(UserReference)}.
     *
     * <p><b>Note:</b> {@link net.dv8tion.jda.api.entities.Guild#getMembers()} will still contain the {@link net.dv8tion.jda.api.entities.User User's}
     * {@link Member Member} object (if the User was in the Guild)
     * until Discord sends the {@link net.dv8tion.jda.api.events.guild.member.GuildMemberRemoveEvent GuildMemberRemoveEvent}.
     *
     * <p><b>Examples</b><br>
     * Banning a user without deleting any messages:
     * {@snippet lang="java":
     * guild.ban(user, 0, TimeUnit.SECONDS)
     *      .reason("Banned for rude behavior")
     *      .queue();
     * }
     * Banning a user and deleting messages from the past hour:
     * {@snippet lang="java":
     * guild.ban(user, 1, TimeUnit.HOURS)
     *      .reason("Banned for spamming")
     *      .queue();
     * }
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be banned due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_USER UNKNOWN_USER}
     *     <br>The user does not exist</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} for the user to ban.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  deletionTimeframe
     *         The timeframe for the history of messages that will be deleted. (seconds precision)
     * @param  unit
     *         Timeframe unit as a {@link TimeUnit} (for example {@code ban(user, 7, TimeUnit.DAYS)}).
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#BAN_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the logged in account cannot ban the other user due to permission hierarchy position.
     *         <br>See {@link Member#canInteract(Member)}
     * @throws java.lang.IllegalArgumentException
     *         <ul>
     *             <li>If the provided deletionTimeframe is negative.</li>
     *             <li>If the provided deletionTimeframe is longer than 7 days.</li>
     *             <li>If the provided user or time unit is {@code null}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction}
     *
     * @see    AuditableRestAction#reason(String)
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> ban(@Nonnull UserSnowflake user, int deletionTimeframe, @Nonnull TimeUnit unit);

    /**
     * Bans up to 200 of the provided users.
     * <br>To set a ban reason, use {@link AuditableRestAction#reason(String)}.
     *
     * <p>The {@link BulkBanResponse} includes a list of {@link BulkBanResponse#getFailedUsers() failed users},
     * which is populated with users that could not be banned, for instance due to some internal server error or permission issues.
     * This list of failed users also includes all users that were already banned.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be banned due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#FAILED_TO_BAN_USERS FAILED_TO_BAN_USERS}
     *     <br>None of the users could be banned</li>
     * </ul>
     *
     * @param  users
     *         The users to ban
     * @param  deletionTime
     *         Delete recent messages of the given timeframe (for instance the last hour with {@code Duration.ofHours(1)})
     *
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If any of the provided users is the guild owner or has a higher or equal role position
     * @throws InsufficientPermissionException
     *         If the bot does not have {@link Permission#BAN_MEMBERS} or {@link Permission#MANAGE_SERVER}
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the users collection is null or contains null</li>
     *             <li>If the deletionTime is negative</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction} - Type: {@link BulkBanResponse}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<BulkBanResponse> ban(
            @Nonnull Collection<? extends UserSnowflake> users, @Nullable Duration deletionTime);

    /**
     * Bans up to 200 of the provided users.
     * <br>To set a ban reason, use {@link AuditableRestAction#reason(String)}.
     *
     * <p>The {@link BulkBanResponse} includes a list of {@link BulkBanResponse#getFailedUsers() failed users},
     * which is populated with users that could not be banned, for instance due to some internal server error or permission issues.
     * This list of failed users also includes all users that were already banned.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be banned due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#FAILED_TO_BAN_USERS FAILED_TO_BAN_USERS}
     *     <br>None of the users could be banned</li>
     * </ul>
     *
     * @param  users
     *         The users to ban
     * @param  deletionTimeframe
     *         The timeframe for the history of messages that will be deleted. (seconds precision)
     * @param  unit
     *         Timeframe unit as a {@link TimeUnit} (for example {@code ban(user, 7, TimeUnit.DAYS)}).
     *
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If any of the provided users is the guild owner or has a higher or equal role position
     * @throws InsufficientPermissionException
     *         If the bot does not have {@link Permission#BAN_MEMBERS} or {@link Permission#MANAGE_SERVER}
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If null is provided</li>
     *             <li>If the deletionTimeframe is negative</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction} - Type: {@link BulkBanResponse}
     */
    @Nonnull
    @CheckReturnValue
    default AuditableRestAction<BulkBanResponse> ban(
            @Nonnull Collection<? extends UserSnowflake> users, int deletionTimeframe, @Nonnull TimeUnit unit) {
        Checks.notNull(unit, "TimeUnit");
        return ban(users, Duration.ofSeconds(unit.toSeconds(deletionTimeframe)));
    }

    /**
     * Unbans the specified {@link UserSnowflake} from this Guild.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be unbanned due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_BAN UNKNOWN_BAN}
     *     <br>The specified User is not banned from the current Guild</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_USER UNKNOWN_USER}
     *     <br>The specified User does not exist</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} to unban.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#BAN_MEMBERS} permission.
     * @throws IllegalArgumentException
     *         If the provided user is null
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> unban(@Nonnull UserSnowflake user);

    /**
     * Puts the specified Member in time out in this {@link net.dv8tion.jda.api.entities.Guild Guild} for a specific amount of time.
     * <br>While a Member is in time out, they cannot send messages, reply, react, or speak in voice channels.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be put into time out due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} to timeout.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  amount
     *         The amount of the provided {@link TimeUnit unit} to put the specified Member in time out for
     * @param  unit
     *         The {@link TimeUnit Unit} type of {@code amount}
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MODERATE_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the logged in account cannot put a timeout on the other Member due to permission hierarchy position. (See {@link Member#canInteract(Member)})
     * @throws IllegalArgumentException
     *         If any of the following checks are true
     *         <ul>
     *             <li>The provided {@code user} is null</li>
     *             <li>The provided {@code amount} is lower than or equal to {@code 0}</li>
     *             <li>The provided {@code unit} is null</li>
     *             <li>The provided {@code amount} with the {@code unit} results in a date that is more than {@value Member#MAX_TIME_OUT_LENGTH} days in the future</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    default AuditableRestAction<Void> timeoutFor(@Nonnull UserSnowflake user, long amount, @Nonnull TimeUnit unit) {
        Checks.check(amount >= 1, "The amount must be more than 0");
        Checks.notNull(unit, "TimeUnit");
        return timeoutUntil(user, Helpers.toOffset(System.currentTimeMillis() + unit.toMillis(amount)));
    }

    /**
     * Puts the specified Member in time out in this {@link net.dv8tion.jda.api.entities.Guild Guild} for a specific amount of time.
     * <br>While a Member is in time out, all permissions except {@link net.dv8tion.jda.api.Permission#VIEW_CHANNEL VIEW_CHANNEL} and
     * {@link net.dv8tion.jda.api.Permission#MESSAGE_HISTORY MESSAGE_HISTORY} are removed from them.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be put into time out due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} to timeout.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  duration
     *         The duration to put the specified Member in time out for
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MODERATE_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the logged in account cannot put a timeout on the other Member due to permission hierarchy position.
     *         <br>See {@link Member#canInteract(Member)}
     * @throws IllegalArgumentException
     *         If any of the following checks are true
     *         <ul>
     *             <li>The provided {@code user} is null</li>
     *             <li>The provided {@code duration} is null</li>
     *             <li>The provided {@code duration} results in a date that is more than {@value Member#MAX_TIME_OUT_LENGTH} days in the future</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    default AuditableRestAction<Void> timeoutFor(@Nonnull UserSnowflake user, @Nonnull Duration duration) {
        Checks.notNull(duration, "Duration");
        return timeoutUntil(user, Helpers.toOffset(System.currentTimeMillis() + duration.toMillis()));
    }

    /**
     * Puts the specified Member in time out in this {@link net.dv8tion.jda.api.entities.Guild Guild} until the specified date.
     * <br>While a Member is in time out, all permissions except {@link net.dv8tion.jda.api.Permission#VIEW_CHANNEL VIEW_CHANNEL} and
     * {@link net.dv8tion.jda.api.Permission#MESSAGE_HISTORY MESSAGE_HISTORY} are removed from them.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be put into time out due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} to timeout.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  temporal
     *         The time the specified Member will be released from time out
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MODERATE_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the logged in account cannot put a timeout on the other Member due to permission hierarchy position. (See {@link Member#canInteract(Member)})
     * @throws IllegalArgumentException
     *         If any of the following are true
     *         <ul>
     *             <li>The provided {@code user} is null</li>
     *             <li>The provided {@code temporal} is null</li>
     *             <li>The provided {@code temporal} is in the past</li>
     *             <li>The provided {@code temporal} is more than {@value Member#MAX_TIME_OUT_LENGTH} days in the future</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> timeoutUntil(@Nonnull UserSnowflake user, @Nonnull TemporalAccessor temporal);

    /**
     * Removes a time out from the specified Member in this {@link net.dv8tion.jda.api.entities.Guild Guild}.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The time out cannot be removed due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} to timeout.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MODERATE_MEMBERS} permission.
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the logged in account cannot remove the timeout from the other Member due to permission hierarchy position. (See {@link Member#canInteract(Member)})
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> removeTimeout(@Nonnull UserSnowflake user);

    /**
     * Sets the Guild Deafened state of the {@link Member Member} based on the provided
     * boolean.
     *
     * <p><b>Note:</b> The Member's {@link GuildVoiceState#isGuildDeafened() GuildVoiceState.isGuildDeafened()} value won't change
     * until JDA receives the {@link net.dv8tion.jda.api.events.guild.voice.GuildVoiceGuildDeafenEvent GuildVoiceGuildDeafenEvent} event related to this change.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be deafened due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#USER_NOT_CONNECTED USER_NOT_CONNECTED}
     *     <br>The specified Member is not connected to a voice channel</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} who's {@link GuildVoiceState} to change.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  deafen
     *         Whether this {@link Member Member} should be deafened or undeafened.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#VOICE_DEAF_OTHERS} permission
     *         in the given channel.
     * @throws IllegalArgumentException
     *         If the provided user is null.
     * @throws java.lang.IllegalStateException
     *         If the provided user is not currently connected to a voice channel.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> deafen(@Nonnull UserSnowflake user, boolean deafen);

    /**
     * Sets the Guild Muted state of the {@link Member Member} based on the provided
     * boolean.
     *
     * <p><b>Note:</b> The Member's {@link GuildVoiceState#isGuildMuted() GuildVoiceState.isGuildMuted()} value won't change
     * until JDA receives the {@link net.dv8tion.jda.api.events.guild.voice.GuildVoiceGuildMuteEvent GuildVoiceGuildMuteEvent} event related to this change.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The target Member cannot be muted due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The specified Member was removed from the Guild before finishing the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#USER_NOT_CONNECTED USER_NOT_CONNECTED}
     *     <br>The specified Member is not connected to a voice channel</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} who's {@link GuildVoiceState} to change.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  mute
     *         Whether this {@link Member Member} should be muted or unmuted.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#VOICE_DEAF_OTHERS} permission
     *         in the given channel.
     * @throws java.lang.IllegalArgumentException
     *         If the provided user is null.
     * @throws java.lang.IllegalStateException
     *         If the provided user is not currently connected to a voice channel.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> mute(@Nonnull UserSnowflake user, boolean mute);

    /**
     * Atomically assigns the provided {@link Role Role} to the specified {@link Member Member}.
     * <br><b>This can be used together with other role modification methods as it does not require an updated cache!</b>
     *
     * <p>If multiple roles should be added/removed (efficiently) in one request
     * you may use {@link #modifyMemberRoles(Member, Collection, Collection) modifyMemberRoles(Member, Collection, Collection)} or similar methods.
     *
     * <p>If the specified role is already present in the member's set of roles this does nothing.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The Members Roles could not be modified due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The target Member was removed from the Guild before finishing the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_ROLE UNKNOWN_ROLE}
     *     <br>If the specified Role does not exist</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} to change roles for.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  role
     *         The role which should be assigned atomically
     *
     * @throws java.lang.IllegalArgumentException
     *         <ul>
     *             <li>If the specified member or role are not from the current Guild</li>
     *             <li>Either member or role are {@code null}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES Permission.MANAGE_ROLES}
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the provided roles are higher in the Guild's hierarchy
     *         and thus cannot be modified by the currently logged in account
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> addRoleToMember(@Nonnull UserSnowflake user, @Nonnull Role role);

    /**
     * Atomically removes the provided {@link Role Role} from the specified {@link Member Member}.
     * <br><b>This can be used together with other role modification methods as it does not require an updated cache!</b>
     *
     * <p>If multiple roles should be added/removed (efficiently) in one request
     * you may use {@link #modifyMemberRoles(Member, Collection, Collection) modifyMemberRoles(Member, Collection, Collection)} or similar methods.
     *
     * <p>If the specified role is not present in the member's set of roles this does nothing.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The Members Roles could not be modified due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The target Member was removed from the Guild before finishing the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_ROLE UNKNOWN_ROLE}
     *     <br>If the specified Role does not exist</li>
     * </ul>
     *
     * @param  user
     *         The {@link UserSnowflake} to change roles for.
     *         This can be a member or user instance or {@link User#fromId(long)}.
     * @param  role
     *         The role which should be removed atomically
     *
     * @throws java.lang.IllegalArgumentException
     *         <ul>
     *             <li>If the specified member or role are not from the current Guild</li>
     *             <li>Either member or role are {@code null}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES Permission.MANAGE_ROLES}
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the provided roles are higher in the Guild's hierarchy
     *         and thus cannot be modified by the currently logged in account
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> removeRoleFromMember(@Nonnull UserSnowflake user, @Nonnull Role role);

    /**
     * Modifies the {@link Role Roles} of the specified {@link Member Member}
     * by adding and removing a collection of roles.
     * <br>None of the provided roles may be the <u>Public Role</u> of the current Guild.
     * <br>If a role is both in {@code rolesToAdd} and {@code rolesToRemove} it will be removed.
     *
     * <p><b>Example</b><br>
     * {@snippet lang="java":
     * public static void promote(Member member) {
     *     Guild guild = member.getGuild();
     *     List<Role> pleb = guild.getRolesByName("Pleb", true); // remove all roles named "pleb"
     *     List<Role> knight = guild.getRolesByName("Knight", true); // add all roles named "knight"
     *     // update roles in single request
     *     guild.modifyMemberRoles(member, knight, pleb).queue();
     * }
     * }
     *
     * <p><b>Warning</b><br>
     * <b>This may <u>not</u> be used together with any other role add/remove/modify methods for the same Member
     * within one event listener cycle! The changes made by this require cache updates which are triggered by
     * lifecycle events which are received later. This may only be called again once the specific Member has been updated
     * by a {@link net.dv8tion.jda.api.events.guild.member.GenericGuildMemberEvent GenericGuildMemberEvent} targeting the same Member.</b>
     *
     * <p>This is logically equivalent to:
     * {@snippet lang="java":
     * Set<Role> roles = new HashSet<>(member.getRoles());
     * roles.addAll(rolesToAdd);
     * roles.removeAll(rolesToRemove);
     * RestAction<Void> action = guild.modifyMemberRoles(member, roles);
     * }
     *
     * <p>You can use {@link #addRoleToMember(UserSnowflake, Role)} and {@link #removeRoleFromMember(UserSnowflake, Role)} to make updates
     * independent of the cache.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The Members Roles could not be modified due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The target Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * @param  member
     *         The {@link Member Member} that should be modified
     * @param  rolesToAdd
     *         A {@link java.util.Collection Collection} of {@link Role Roles}
     *         to add to the current Roles the specified {@link Member Member} already has, or null
     * @param  rolesToRemove
     *         A {@link java.util.Collection Collection} of {@link Role Roles}
     *         to remove from the current Roles the specified {@link Member Member} already has, or null
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES Permission.MANAGE_ROLES}
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the provided roles are higher in the Guild's hierarchy
     *         and thus cannot be modified by the currently logged in account
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the target member is {@code null}</li>
     *             <li>If any of the specified Roles is managed or is the {@code Public Role} of the Guild</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> modifyMemberRoles(
            @Nonnull Member member, @Nullable Collection<Role> rolesToAdd, @Nullable Collection<Role> rolesToRemove);

    /**
     * Modifies the complete {@link Role Role} set of the specified {@link Member Member}
     * <br>The provided roles will replace all current Roles of the specified Member.
     *
     * <p><b>Warning</b><br>
     * <b>This may <u>not</u> be used together with any other role add/remove/modify methods for the same Member
     * within one event listener cycle! The changes made by this require cache updates which are triggered by
     * lifecycle events which are received later. This may only be called again once the specific Member has been updated
     * by a {@link net.dv8tion.jda.api.events.guild.member.GenericGuildMemberEvent GenericGuildMemberEvent} targeting the same Member.</b>
     *
     * <p><b>The new roles <u>must not</u> contain the Public Role of the Guild</b>
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The Members Roles could not be modified due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The target Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * <p><b>Example</b><br>
     * {@snippet lang="java":
     * public static void removeRoles(Member member) {
     *     Guild guild = member.getGuild();
     *     // pass no role, this means we set the roles of the member to an empty array.
     *     guild.modifyMemberRoles(member).queue();
     * }
     * }
     *
     * @param  member
     *         A {@link Member Member} of which to override the Roles of
     * @param  roles
     *         New collection of {@link Role Roles} for the specified Member
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES Permission.MANAGE_ROLES}
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the provided roles are higher in the Guild's hierarchy
     *         and thus cannot be modified by the currently logged in account
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If any of the provided arguments is {@code null}</li>
     *             <li>If any of the provided arguments is not from this Guild</li>
     *             <li>If any of the specified {@link Role Roles} is managed</li>
     *             <li>If any of the specified {@link Role Roles} is the {@code Public Role} of this Guild</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     *
     * @see    #modifyMemberRoles(Member, Collection)
     */
    @Nonnull
    @CheckReturnValue
    default AuditableRestAction<Void> modifyMemberRoles(@Nonnull Member member, @Nonnull Role... roles) {
        return modifyMemberRoles(member, Arrays.asList(roles));
    }

    /**
     * Modifies the complete {@link Role Role} set of the specified {@link Member Member}
     * <br>The provided roles will replace all current Roles of the specified Member.
     *
     * <p><u>The new roles <b>must not</b> contain the Public Role of the Guild</u>
     *
     * <p><b>Warning</b><br>
     * <b>This may <u>not</u> be used together with any other role add/remove/modify methods for the same Member
     * within one event listener cycle! The changes made by this require cache updates which are triggered by
     * lifecycle events which are received later. This may only be called again once the specific Member has been updated
     * by a {@link net.dv8tion.jda.api.events.guild.member.GenericGuildMemberEvent GenericGuildMemberEvent} targeting the same Member.</b>
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The Members Roles could not be modified due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_MEMBER UNKNOWN_MEMBER}
     *     <br>The target Member was removed from the Guild before finishing the task</li>
     * </ul>
     *
     * <p><b>Example</b><br>
     * {@snippet lang="java":
     * public static void makeModerator(Member member) {
     *     Guild guild = member.getGuild();
     *     List<Role> roles = new ArrayList<>(member.getRoles()); // modifiable copy
     *     List<Role> modRoles = guild.getRolesByName("moderator", true); // get roles with name "moderator"
     *     roles.addAll(modRoles); // add new roles
     *     // update the member with new roles
     *     guild.modifyMemberRoles(member, roles).queue();
     * }
     * }
     *
     * @param  member
     *         A {@link Member Member} of which to override the Roles of
     * @param  roles
     *         New collection of {@link Role Roles} for the specified Member
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES Permission.MANAGE_ROLES}
     * @throws net.dv8tion.jda.api.exceptions.HierarchyException
     *         If the provided roles are higher in the Guild's hierarchy
     *         and thus cannot be modified by the currently logged in account
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If any of the provided arguments is {@code null}</li>
     *             <li>If any of the provided arguments is not from this Guild</li>
     *             <li>If any of the specified {@link Role Roles} is managed</li>
     *             <li>If any of the specified {@link Role Roles} is the {@code Public Role} of this Guild</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction}
     *
     * @see    #modifyMemberRoles(Member, Collection)
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> modifyMemberRoles(@Nonnull Member member, @Nonnull Collection<Role> roles);

    /**
     * Returns a {@link RoleMemberCounts} object with the member count of each role,
     * except for the {@linkplain #getPublicRole() @everyone} role.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A {@link RoleMemberCounts} object
     */
    @Nonnull
    @CheckReturnValue
    RestAction<RoleMemberCounts> retrieveRoleMemberCounts();

    /**
     * Creates a new {@link TextChannel TextChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the TextChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link net.dv8tion.jda.api.requests.restaction.ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new TextChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    default ChannelAction<TextChannel> createTextChannel(@Nonnull String name) {
        return createTextChannel(name, null);
    }

    /**
     * Creates a new {@link TextChannel TextChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the TextChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     * @param  parent
     *         The optional parent category for this channel, or null
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters;
     *         or the provided parent is not in the same guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link net.dv8tion.jda.api.requests.restaction.ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new TextChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    ChannelAction<TextChannel> createTextChannel(@Nonnull String name, @Nullable Category parent);

    /**
     * Creates a new {@link NewsChannel NewsChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the NewsChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link net.dv8tion.jda.api.requests.restaction.ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new NewsChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    default ChannelAction<NewsChannel> createNewsChannel(@Nonnull String name) {
        return createNewsChannel(name, null);
    }

    /**
     * Creates a new {@link NewsChannel NewsChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the NewsChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     * @param  parent
     *         The optional parent category for this channel, or null
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters;
     *         or the provided parent is not in the same guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link net.dv8tion.jda.api.requests.restaction.ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new NewsChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    ChannelAction<NewsChannel> createNewsChannel(@Nonnull String name, @Nullable Category parent);

    /**
     * Creates a new {@link VoiceChannel VoiceChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the VoiceChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new VoiceChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    default ChannelAction<VoiceChannel> createVoiceChannel(@Nonnull String name) {
        return createVoiceChannel(name, null);
    }

    /**
     * Creates a new {@link VoiceChannel VoiceChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the VoiceChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     * @param  parent
     *         The optional parent category for this channel, or null
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters;
     *         or the provided parent is not in the same guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new VoiceChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    ChannelAction<VoiceChannel> createVoiceChannel(@Nonnull String name, @Nullable Category parent);

    /**
     * Creates a new {@link StageChannel StageChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the StageChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new StageChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    default ChannelAction<StageChannel> createStageChannel(@Nonnull String name) {
        return createStageChannel(name, null);
    }

    /**
     * Creates a new {@link StageChannel StageChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the StageChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     * @param  parent
     *         The optional parent category for this channel, or null
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters;
     *         or the provided parent is not in the same guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new StageChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    ChannelAction<StageChannel> createStageChannel(@Nonnull String name, @Nullable Category parent);

    /**
     * Creates a new {@link ForumChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the ForumChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new ForumChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    default ChannelAction<ForumChannel> createForumChannel(@Nonnull String name) {
        return createForumChannel(name, null);
    }

    /**
     * Creates a new {@link ForumChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the ForumChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     * @param  parent
     *         The optional parent category for this channel, or null
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters;
     *         or the provided parent is not in the same guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new ForumChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    ChannelAction<ForumChannel> createForumChannel(@Nonnull String name, @Nullable Category parent);

    /**
     * Creates a new {@link MediaChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the MediaChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new MediaChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    default ChannelAction<MediaChannel> createMediaChannel(@Nonnull String name) {
        return createMediaChannel(name, null);
    }

    /**
     * Creates a new {@link MediaChannel} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the MediaChannel to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     * @param  parent
     *         The optional parent category for this channel, or null
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters;
     *         or the provided parent is not in the same guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new MediaChannel before creating it
     */
    @Nonnull
    @CheckReturnValue
    ChannelAction<MediaChannel> createMediaChannel(@Nonnull String name, @Nullable Category parent);

    /**
     * Creates a new {@link Category Category} in this Guild.
     * For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  name
     *         The name of the Category to create (up to {@value Channel#MAX_NAME_LENGTH} characters)
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL} permission
     * @throws IllegalArgumentException
     *         If the provided name is {@code null}, blank, or longer than {@value Channel#MAX_NAME_LENGTH} characters
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new Category before creating it
     */
    @Nonnull
    @CheckReturnValue
    ChannelAction<Category> createCategory(@Nonnull String name);

    /**
     * Creates a copy of the specified {@link GuildChannel GuildChannel}
     * in this {@link net.dv8tion.jda.api.entities.Guild Guild}.
     * <br>The provided channel need not be in the same Guild for this to work!
     *
     * <p>This copies the following elements:
     * <ol>
     *     <li>Name</li>
     *     <li>Parent Category (if present)</li>
     *     <li>Voice Elements (Bitrate, Userlimit)</li>
     *     <li>Text Elements (Topic, NSFW)</li>
     *     <li>All permission overrides for Members/Roles</li>
     * </ol>
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The channel could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_CHANNELS MAX_CHANNELS}
     *     <br>The maximum number of channels were exceeded</li>
     * </ul>
     *
     * @param  <T>
     *         The channel type
     * @param  channel
     *         The {@link GuildChannel GuildChannel} to use for the copy template
     *
     * @throws java.lang.IllegalArgumentException
     *         If the provided channel is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_CHANNEL MANAGE_CHANNEL} Permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return A specific {@link ChannelAction ChannelAction}
     *         <br>This action allows to set fields for the new GuildChannel before creating it!
     *
     * @see    #createTextChannel(String)
     * @see    #createVoiceChannel(String)
     * @see    ChannelAction ChannelAction
     */
    @Nonnull
    @CheckReturnValue
    @SuppressWarnings("unchecked") // we need to do an unchecked cast for the channel type here
    default <T extends ICopyableChannel> ChannelAction<T> createCopyOfChannel(@Nonnull T channel) {
        Checks.notNull(channel, "Channel");
        return (ChannelAction<T>) channel.createCopy(this);
    }

    /**
     * Creates a new {@link Role Role} in this Guild.
     * <br>It will be placed at the bottom (just over the Public Role) to avoid permission hierarchy conflicts.
     * <br>For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES MANAGE_ROLES} Permission
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The role could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_ROLES_PER_GUILD MAX_ROLES_PER_GUILD}
     *     <br>There are too many roles in this Guild</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES} Permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.RoleAction RoleAction}
     *         <br>Creates a new role with previously selected field values
     */
    @Nonnull
    @CheckReturnValue
    RoleAction createRole();

    /**
     * Creates a new {@link Role Role} in this {@link net.dv8tion.jda.api.entities.Guild Guild}
     * with the same settings as the given {@link Role Role}.
     * <br>The position of the specified Role does not matter in this case!
     *
     * <p>It will be placed at the bottom (just over the Public Role) to avoid permission hierarchy conflicts.
     * <br>For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES MANAGE_ROLES} Permission
     * and all {@link net.dv8tion.jda.api.Permission Permissions} the given {@link Role Role} has.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The role could not be created due to a permission discrepancy</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_ROLES_PER_GUILD MAX_ROLES_PER_GUILD}
     *     <br>There are too many roles in this Guild</li>
     * </ul>
     *
     * @param  role
     *         The {@link Role Role} that should be copied
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#MANAGE_ROLES} Permission and every Permission the provided Role has
     * @throws java.lang.IllegalArgumentException
     *         If the specified role is {@code null}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RoleAction RoleAction}
     *         <br>RoleAction with already copied values from the specified {@link Role Role}
     */
    @Nonnull
    @CheckReturnValue
    default RoleAction createCopyOfRole(@Nonnull Role role) {
        Checks.notNull(role, "Role");
        return role.createCopy(this);
    }

    /**
     * Creates a new {@link RichCustomEmoji} in this Guild.
     * <br>If one or more Roles are specified the new emoji will only be available to Members with any of the specified Roles (see {@link Member#canInteract(RichCustomEmoji)})
     * <br>For this to be successful, the logged in account has to have the {@link net.dv8tion.jda.api.Permission#CREATE_GUILD_EXPRESSIONS CREATE_GUILD_EXPRESSIONS} Permission.
     *
     * <p><b><u>Unicode emojis are not included as {@link RichCustomEmoji}!</u></b>
     *
     * <p>Note that a guild is limited to 50 normal and 50 animated emojis by default.
     * Some guilds are able to add additional emojis beyond this limitation due to the
     * {@code MORE_EMOJI} feature (see {@link net.dv8tion.jda.api.entities.Guild#getFeatures() Guild.getFeatures()}).
     * <br>Due to simplicity we do not check for these limits.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The emoji could not be created due to a permission discrepancy</li>
     * </ul>
     *
     * @param  name
     *         The name for the new emoji
     * @param  icon
     *         The {@link Icon} for the new emoji
     * @param  roles
     *         The {@link Role Roles} the new emoji should be restricted to
     *         <br>If no roles are provided the emoji will be available to all Members of this Guild
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the logged in account does not have the {@link net.dv8tion.jda.api.Permission#CREATE_GUILD_EXPRESSIONS CREATE_GUILD_EXPRESSIONS} Permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.AuditableRestAction AuditableRestAction} - Type: {@link RichCustomEmoji}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<RichCustomEmoji> createEmoji(@Nonnull String name, @Nonnull Icon icon, @Nonnull Role... roles);

    /**
     * Creates a new {@link GuildSticker} in this Guild.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVALID_FILE_UPLOADED INVALID_FILE_UPLOADED}
     *     <br>The sticker file asset is not in a supported file format</li>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The sticker could not be created due to a permission discrepancy</li>
     * </ul>
     *
     * @param  name
     *         The sticker name (2-30 characters)
     * @param  description
     *         The sticker description (2-100 characters, or empty)
     * @param  file
     *         The sticker file containing the asset (png/apng/gif/lottie) with valid file extension (png, gif, or json)
     * @param  tags
     *         The tags to use for auto-suggestions (Up to 200 characters in total)
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#CREATE_GUILD_EXPRESSIONS CREATE_GUILD_EXPRESSIONS} permission
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the name is not between 2 and 30 characters long</li>
     *             <li>If the description is more than 100 characters long or exactly 1 character long</li>
     *             <li>If the asset file is null or of an invalid format (must be PNG, GIF, or LOTTIE)</li>
     *             <li>If anything is {@code null}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction} - Type: {@link GuildSticker}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<GuildSticker> createSticker(
            @Nonnull String name,
            @Nonnull String description,
            @Nonnull FileUpload file,
            @Nonnull Collection<String> tags);

    /**
     * Creates a new {@link GuildSticker} in this Guild.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVALID_FILE_UPLOADED INVALID_FILE_UPLOADED}
     *     <br>The sticker file asset is not in a supported file format</li>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The sticker could not be created due to a permission discrepancy</li>
     * </ul>
     *
     * @param  name
     *         The sticker name (2-30 characters)
     * @param  description
     *         The sticker description (2-100 characters, or empty)
     * @param  file
     *         The sticker file containing the asset (png/apng/gif/lottie) with valid file extension (png, gif, or json)
     * @param  tag
     *         The sticker tag used for suggestions (emoji or tag words)
     * @param  tags
     *         Additional tags to use for suggestions
     *
     * @throws InsufficientPermissionException
     *         If the currently logged in account does not have the {@link net.dv8tion.jda.api.Permission#CREATE_GUILD_EXPRESSIONS CREATE_GUILD_EXPRESSIONS} permission
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If the name is not between 2 and 30 characters long</li>
     *             <li>If the description is more than 100 characters long or exactly 1 character long</li>
     *             <li>If the asset file is null or of an invalid format (must be PNG, GIF, or LOTTIE)</li>
     *             <li>If anything is {@code null}</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction} - Type: {@link GuildSticker}
     */
    @Nonnull
    @CheckReturnValue
    default AuditableRestAction<GuildSticker> createSticker(
            @Nonnull String name,
            @Nonnull String description,
            @Nonnull FileUpload file,
            @Nonnull String tag,
            @Nonnull String... tags) {
        List<String> list = new ArrayList<>(tags.length + 1);
        list.add(tag);
        Collections.addAll(list, tags);
        return createSticker(name, description, file, list);
    }

    /**
     * Deletes a sticker from the guild.
     *
     * <p>The returned {@link net.dv8tion.jda.api.requests.RestAction RestAction} can encounter the following Discord errors:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_STICKER UNKNOWN_STICKER}
     *     <br>Occurs when the provided id does not refer to a sticker known by Discord.</li>
     * </ul>
     *
     * @throws IllegalStateException
     *         If null is provided
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link Permission#MANAGE_GUILD_EXPRESSIONS MANAGE_GUILD_EXPRESSIONS}
     *         nor {@link Permission#CREATE_GUILD_EXPRESSIONS CREATE_GUILD_EXPRESSIONS} in the guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> deleteSticker(@Nonnull StickerSnowflake id);

    /**
     * Creates a soundboard sound in the guild.
     *
     * <p>The returned {@link RestAction} can encounter the following {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses}:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVALID_FILE_EXCEEDS_MAXIMUM_LENGTH INVALID_FILE_EXCEEDS_MAXIMUM_LENGTH}
     *     <br>The provided file exceeds the duration of 5.2 seconds</li>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MAX_SOUNDBOARD_SOUNDS MAX_SOUNDBOARD_SOUNDS}
     *     <br>The maximum amount of soundboard sounds have been created, depends on the server boosts</li>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVALID_EMOJI INVALID_EMOJI}
     *     <br>The emoji is invalid</li>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVALID_FORM_BODY INVALID_FORM_BODY}
     *     <br>The file is too large</li>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#INVALID_FILE INVALID_FILE}
     *     <br>The file is malformed</li>
     * </ul>
     *
     * @param name
     *        The name of the soundboard sound, must be between 2-32 characters
     * @param file
     *        The file to use as the sound, can be an MP3 or an OGG file
     *
     * @throws IllegalArgumentException
     *         <ul>
     *             <li>If {@code null} is provided</li>
     *             <li>If {@code name} is not between 2-32 characters</li>
     *             <li>If the file is not of the correct type</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link Permission#CREATE_GUILD_EXPRESSIONS CREATE_GUILD_EXPRESSIONS} in the guild.
     *
     * @return {@link SoundboardSoundCreateAction}
     */
    @Nonnull
    @CheckReturnValue
    SoundboardSoundCreateAction createSoundboardSound(@Nonnull String name, @Nonnull FileUpload file);

    /**
     * Deletes a soundboard sound from the guild.
     *
     * <p>The returned {@link net.dv8tion.jda.api.requests.RestAction RestAction} can encounter the following Discord errors:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_SOUND UNKNOWN_SOUND}
     *     <br>Occurs when the provided id does not refer to a soundboard sound known by Discord.</li>
     *     <li>{@link ErrorResponse#MISSING_PERMISSIONS MISSING_PERMISSIONS}
     *     <br>The sound cannot be deleted due to a permission discrepancy</li>
     * </ul>
     *
     * @param  sound
     *         The reference of the {@link SoundboardSound}.
     *
     * @throws IllegalStateException
     *         If {@code null} is provided
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link Permission#MANAGE_GUILD_EXPRESSIONS MANAGE_GUILD_EXPRESSIONS} in the guild.
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link AuditableRestAction}
     */
    @Nonnull
    @CheckReturnValue
    AuditableRestAction<Void> deleteSoundboardSound(@Nonnull SoundboardSoundSnowflake sound);

    /**
     * Creates a new {@link ScheduledEvent}.
     * Events created with this method will be of {@link ScheduledEvent.Type#EXTERNAL Type.EXTERNAL}.
     * These events are set to take place at an external location.
     *
     * <p><b>Requirements</b><br>
     *
     * Events are required to have a name, location and start time.
     * Additionally, an end time <em>must</em> also be specified for events of {@link ScheduledEvent.Type#EXTERNAL Type.EXTERNAL}.
     * {@link Permission#CREATE_SCHEDULED_EVENTS} is required on the guild level in order to create this type of event.
     *
     * <p><b>Example</b><br>
     * {@snippet lang="java":
     * guild.createScheduledEvent("Cactus Beauty Contest", "Mike's Backyard", OffsetDateTime.now().plusHours(1), OffsetDateTime.now().plusHours(3))
     *     .setDescription("Come and have your cacti judged! _Must be spikey to enter_")
     *     .queue();
     * }
     *
     * @param  name
     *         the name for this scheduled event, 1-100 characters
     * @param  location
     *         the external location for this scheduled event, 1-100 characters
     * @param  startTime
     *         the start time for this scheduled event, can't be in the past or after the end time
     * @param  endTime
     *         the end time for this scheduled event, has to be later than the start time
     *
     * @throws java.lang.IllegalArgumentException
     *         <ul>
     *             <li>If a required parameter is {@code null} or empty</li>
     *             <li>If the start time is in the past</li>
     *             <li>If the end time is before the start time</li>
     *             <li>If the name is longer than 100 characters</li>
     *             <li>If the description is longer than 1000 characters</li>
     *             <li>If the location is longer than 100 characters</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link ScheduledEventAction}
     */
    @Nonnull
    @CheckReturnValue
    ScheduledEventAction createScheduledEvent(
            @Nonnull String name,
            @Nonnull String location,
            @Nonnull OffsetDateTime startTime,
            @Nonnull OffsetDateTime endTime);

    /**
     * Creates a new {@link ScheduledEvent}.
     *
     * <p><b>Requirements</b><br>
     *
     * Events are required to have a name, channel and start time. Depending on the
     * type of channel provided, an event will be of one of two different {@link ScheduledEvent.Type Types}:
     * <ol>
     *     <li>
     *         {@link ScheduledEvent.Type#STAGE_INSTANCE Type.STAGE_INSTANCE}
     *         <br>These events are set to take place inside of a {@link StageChannel}. The
     *         following permissions are required in the specified stage channel in order to create an event there:
     *          <ul>
     *              <li>{@link Permission#CREATE_SCHEDULED_EVENTS}</li>
     *              <li>{@link Permission#MANAGE_CHANNEL}</li>
     *              <li>{@link Permission#VOICE_MUTE_OTHERS}</li>
     *              <li>{@link Permission#VOICE_MOVE_OTHERS}}</li>
     *         </ul>
     *     </li>
     *     <li>
     *         {@link ScheduledEvent.Type#VOICE Type.VOICE}
     *         <br>These events are set to take place inside of a {@link VoiceChannel}. The
     *         following permissions are required in the specified voice channel in order to create an event there:
     *         <ul>
     *             <li>{@link Permission#CREATE_SCHEDULED_EVENTS}</li>
     *             <li>{@link Permission#VIEW_CHANNEL}</li>
     *             <li>{@link Permission#VOICE_CONNECT}</li>
     *         </ul>
     *     </li>
     * </ol>
     *
     * <p><b>Example</b><br>
     * {@snippet lang="java":
     * guild.createScheduledEvent("Cactus Beauty Contest", guild.getGuildChannelById(channelId), OffsetDateTime.now().plusHours(1))
     *     .setDescription("Come and have your cacti judged! _Must be spikey to enter_")
     *     .queue();
     * }
     *
     * @param  name
     *         the name for this scheduled event, 1-100 characters
     * @param  channel
     *         the voice or stage channel where this scheduled event will take place
     * @param  startTime
     *         the start time for this scheduled event, can't be in the past
     *
     * @throws java.lang.IllegalArgumentException
     *         <ul>
     *             <li>If a required parameter is {@code null} or empty</li>
     *             <li>If the start time is in the past</li>
     *             <li>If the name is longer than 100 characters</li>
     *             <li>If the description is longer than 1000 characters</li>
     *             <li>If the channel is not a Stage or Voice channel</li>
     *             <li>If the channel is not from the same guild as the scheduled event</li>
     *         </ul>
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link ScheduledEventAction}
     */
    @Nonnull
    @CheckReturnValue
    ScheduledEventAction createScheduledEvent(
            @Nonnull String name, @Nonnull GuildChannel channel, @Nonnull OffsetDateTime startTime);

    /**
     * Searches for messages in this guild.
     * The {@link GatewayIntent#MESSAGE_CONTENT MESSAGE_CONTENT} intent must be enabled in the <a href="https://discord.com/developers/applications" target="_blank">application dashboard</a>.
     * <br>If all you need is to iterate messages of a channel, use {@link MessageChannel#getIterableHistory()} instead.
     *
     * <p>Any invalid entity referenced by the search query, will be ignored.
     *
     * <p><b>Note:</b> The search may return fewer results when messages have not been accessed for a long time.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} caused by
     * the returned {@link RestAction} include the following:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>You are missing the {@link GatewayIntent#MESSAGE_CONTENT MESSAGE_CONTENT} intent, or the search is filtered on a single channel which you don't have access to</li>
     * </ul>
     *
     * <h4>Example - Finding {@code cat.png} attachments sent by users:</h4>
     * {@snippet lang=java:
     * guild.searchMessages()
     *      .attachmentFilenames("cat.png")
     *      .includeAuthorTypes(MessageSearchAction.AuthorType.USER)
     *      .queue(response -> {
     *          if (response.isNotReady()) {
     *              int retryAfter = response.asNotReady().getRetryAfter();
     *              // Reply
     *              return;
     *          }
     *
     *          var results = response.asResults();
     *          var messages = results.getMessages();
     *          // Handle messages
     *      });
     * }
     *
     * @throws InsufficientPermissionException
     *         If the {@linkplain #getSelfMember() current member} does not have the {@link Permission#MESSAGE_HISTORY MESSAGE_HISTORY} permission
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link MessageSearchAction}
     */
    @Nonnull
    @CheckReturnValue
    MessageSearchAction searchMessages();

    /**
     * Modifies the positional order of {@link net.dv8tion.jda.api.entities.Guild#getCategories() Guild.getCategories()}
     * using a specific {@link RestAction RestAction} extension to allow moving Channels
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveUp(int) up}/{@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveDown(int) down}
     * or {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveTo(int) to} a specific position.
     * <br>This uses <b>ascending</b> order with a 0 based index.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_CHANNEL UNNKOWN_CHANNEL}
     *     <br>One of the channels has been deleted before the completion of the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The currently logged in account was removed from the Guild</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.order.ChannelOrderAction ChannelOrderAction} - Type: {@link Category Category}
     */
    @Nonnull
    @CheckReturnValue
    ChannelOrderAction modifyCategoryPositions();

    /**
     * Modifies the positional order of {@link net.dv8tion.jda.api.entities.Guild#getTextChannels() Guild.getTextChannels()}
     * using a specific {@link RestAction RestAction} extension to allow moving Channels
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveUp(int) up}/{@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveDown(int) down}
     * or {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveTo(int) to} a specific position.
     * <br>This uses <b>ascending</b> order with a 0 based index.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_CHANNEL UNNKOWN_CHANNEL}
     *     <br>One of the channels has been deleted before the completion of the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The currently logged in account was removed from the Guild</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link ChannelOrderAction ChannelOrderAction} - Type: {@link TextChannel TextChannel}
     */
    @Nonnull
    @CheckReturnValue
    ChannelOrderAction modifyTextChannelPositions();

    /**
     * Modifies the positional order of {@link net.dv8tion.jda.api.entities.Guild#getVoiceChannels() Guild.getVoiceChannels()}
     * using a specific {@link RestAction RestAction} extension to allow moving Channels
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveUp(int) up}/{@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveDown(int) down}
     * or {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveTo(int) to} a specific position.
     * <br>This uses <b>ascending</b> order with a 0 based index.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_CHANNEL UNNKOWN_CHANNEL}
     *     <br>One of the channels has been deleted before the completion of the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The currently logged in account was removed from the Guild</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link ChannelOrderAction ChannelOrderAction} - Type: {@link VoiceChannel VoiceChannel}
     */
    @Nonnull
    @CheckReturnValue
    ChannelOrderAction modifyVoiceChannelPositions();

    /**
     * Modifies the positional order of {@link Category#getTextChannels() Category#getTextChannels()}
     * using an extension of {@link ChannelOrderAction ChannelOrderAction}
     * specialized for ordering the nested {@link TextChannel TextChannels} of this
     * {@link Category Category}.
     * <br>Like {@code ChannelOrderAction}, the returned {@link net.dv8tion.jda.api.requests.restaction.order.CategoryOrderAction CategoryOrderAction}
     * can be used to move TextChannels {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveUp(int) up},
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveDown(int) down}, or
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveTo(int) to} a specific position.
     * <br>This uses <b>ascending</b> order with a 0 based index.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_CHANNEL UNNKOWN_CHANNEL}
     *     <br>One of the channels has been deleted before the completion of the task.</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The currently logged in account was removed from the Guild.</li>
     * </ul>
     *
     * @param  category
     *         The {@link Category Category} to order
     *         {@link TextChannel TextChannels} from.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link net.dv8tion.jda.api.requests.restaction.order.CategoryOrderAction CategoryOrderAction} - Type: {@link TextChannel TextChannel}
     */
    @Nonnull
    @CheckReturnValue
    CategoryOrderAction modifyTextChannelPositions(@Nonnull Category category);

    /**
     * Modifies the positional order of {@link Category#getVoiceChannels() Category#getVoiceChannels()}
     * using an extension of {@link ChannelOrderAction ChannelOrderAction}
     * specialized for ordering the nested {@link VoiceChannel VoiceChannels} of this
     * {@link Category Category}.
     * <br>Like {@code ChannelOrderAction}, the returned {@link CategoryOrderAction CategoryOrderAction}
     * can be used to move VoiceChannels {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveUp(int) up},
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveDown(int) down}, or
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveTo(int) to} a specific position.
     * <br>This uses <b>ascending</b> order with a 0 based index.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_CHANNEL UNNKOWN_CHANNEL}
     *     <br>One of the channels has been deleted before the completion of the task.</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The currently logged in account was removed from the Guild.</li>
     * </ul>
     *
     * @param  category
     *         The {@link Category Category} to order
     *         {@link VoiceChannel VoiceChannels} from.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link CategoryOrderAction CategoryOrderAction} - Type: {@link VoiceChannel VoiceChannels}
     */
    @Nonnull
    @CheckReturnValue
    CategoryOrderAction modifyVoiceChannelPositions(@Nonnull Category category);

    /**
     * Modifies the positional order of {@link net.dv8tion.jda.api.entities.Guild#getRoles() Guild.getRoles()}
     * using a specific {@link RestAction RestAction} extension to allow moving Roles
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveUp(int) up}/{@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveDown(int) down}
     * or {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveTo(int) to} a specific position.
     *
     * <p>You can also move roles to a position relative to another role, by using {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveBelow(Object) moveBelow(...)}
     * and {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveAbove(Object) moveAbove(...)}.
     *
     * <p>This uses <b>descending</b> ordering which means the highest role is first!
     * <br>This means the lowest role appears at index {@code n - 1} and the highest role at index {@code 0}.
     * <br>Providing {@code true} to {@link #modifyRolePositions(boolean)} will result in the ordering being
     * in ascending order, with the highest role at index {@code n - 1} and the lowest at index {@code 0}.
     *
     * <br>As a note: {@link Member#getRoles() Member.getRoles()}
     * and {@link net.dv8tion.jda.api.entities.Guild#getRoles() Guild.getRoles()} are both in descending order, just like this method.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_ROLE UNKNOWN_ROLE}
     *     <br>One of the roles was deleted before the completion of the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The currently logged in account was removed from the Guild</li>
     * </ul>
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RoleOrderAction}
     */
    @Nonnull
    @CheckReturnValue
    default RoleOrderAction modifyRolePositions() {
        return modifyRolePositions(false);
    }

    /**
     * Modifies the positional order of {@link net.dv8tion.jda.api.entities.Guild#getRoles() Guild.getRoles()}
     * using a specific {@link RestAction RestAction} extension to allow moving Roles
     * {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveUp(int) up}/{@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveDown(int) down}
     * or {@link net.dv8tion.jda.api.requests.restaction.order.OrderAction#moveTo(int) to} a specific position.
     *
     * <p>Possible {@link net.dv8tion.jda.api.requests.ErrorResponse ErrorResponses} include:
     * <ul>
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#UNKNOWN_ROLE UNKNOWN_ROLE}
     *     <br>One of the roles was deleted before the completion of the task</li>
     *
     *     <li>{@link net.dv8tion.jda.api.requests.ErrorResponse#MISSING_ACCESS MISSING_ACCESS}
     *     <br>The currently logged in account was removed from the Guild</li>
     * </ul>
     *
     * @param  useAscendingOrder
     *         Defines the ordering of the OrderAction. If {@code false}, the OrderAction will be in the ordering
     *         defined by Discord for roles, which is Descending. This means that the highest role appears at index {@code 0}
     *         and the lowest role at index {@code n - 1}. Providing {@code true} will result in the ordering being
     *         in ascending order, with the lower role at index {@code 0} and the highest at index {@code n - 1}.
     *         <br>As a note: {@link Member#getRoles() Member.getRoles()}
     *         and {@link net.dv8tion.jda.api.entities.Guild#getRoles() Guild.getRoles()} are both in descending order.
     *
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return {@link RoleOrderAction}
     */
    @Nonnull
    @CheckReturnValue
    RoleOrderAction modifyRolePositions(boolean useAscendingOrder);

    /**
     * The {@link GuildWelcomeScreenManager Manager} for this guild's welcome screen, used to modify
     * properties of the welcome screen like if the welcome screen is enabled, the description and welcome channels.
     * <br>You modify multiple fields in one request by chaining setters before calling {@link net.dv8tion.jda.api.requests.RestAction#queue() RestAction.queue()}.
     *
     * @throws net.dv8tion.jda.api.exceptions.InsufficientPermissionException
     *         If the currently logged in account does not have {@link net.dv8tion.jda.api.Permission#MANAGE_SERVER Permission.MANAGE_SERVER}
     * @throws net.dv8tion.jda.api.exceptions.DetachedEntityException
     *         If this entity is {@link #isDetached() detached}
     *
     * @return The GuildWelcomeScreenManager for this guild's welcome screen
     */
    @Nonnull
    @CheckReturnValue
    GuildWelcomeScreenManager modifyWelcomeScreen();

    /**
     * Represents the idle time allowed until a user is moved to the
     * AFK {@link VoiceChannel} if one is set
     * ({@link net.dv8tion.jda.api.entities.Guild#getAfkChannel() Guild.getAfkChannel()}).
     */
    enum Timeout {
        SECONDS_60(60),
        SECONDS_300(300),
        SECONDS_900(900),
        SECONDS_1800(1800),
        SECONDS_3600(3600);

        private final int seconds;

        Timeout(int seconds) {
            this.seconds = seconds;
        }

        /**
         * The amount of seconds represented by this {@link Timeout}.
         *
         * @return An positive non-negative int representing the timeout amount in seconds.
         */
        public int getSeconds() {
            return seconds;
        }

        /**
         * Retrieves the {@link net.dv8tion.jda.api.entities.Guild.Timeout Timeout} based on the amount of seconds requested.
         * <br>If the {@code seconds} amount provided is not valid for Discord, an IllegalArgumentException will be thrown.
         *
         * @param  seconds
         *         The amount of seconds before idle timeout.
         *
         * @throws java.lang.IllegalArgumentException
         *         If the provided {@code seconds} is an invalid timeout amount.
         *
         * @return The {@link net.dv8tion.jda.api.entities.Guild.Timeout Timeout} related to the amount of seconds provided.
         */
        @Nonnull
        public static Timeout fromKey(int seconds) {
            for (Timeout t : values()) {
                if (t.getSeconds() == seconds) {
                    return t;
                }
            }
            throw new IllegalArgumentException("Provided key was not recognized. Seconds: " + seconds);
        }
    }

    /**
     * Represents the Verification-Level of the Guild.
     * The Verification-Level determines what requirement you have to meet to be able to speak in this Guild.
     * <p>
     * <br><b>None</b>      {@literal ->} everyone can talk.
     * <br><b>Low</b>       {@literal ->} verified email required.
     * <br><b>Medium</b>    {@literal ->} you have to be member of discord for at least 5min.
     * <br><b>High</b>      {@literal ->} you have to be member of this guild for at least 10min.
     * <br><b>Very High</b> {@literal ->} you must have a verified phone on your discord account.
     */
    enum VerificationLevel {
        NONE(0),
        LOW(1),
        MEDIUM(2),
        HIGH(3),
        VERY_HIGH(4),
        UNKNOWN(-1);

        private final int key;

        VerificationLevel(int key) {
            this.key = key;
        }

        /**
         * The Discord id key for this Verification Level.
         *
         * @return Integer id key for this VerificationLevel.
         */
        public int getKey() {
            return key;
        }

        /**
         * Used to retrieve a {@link net.dv8tion.jda.api.entities.Guild.VerificationLevel VerificationLevel} based
         * on the Discord id key.
         *
         * @param  key
         *         The Discord id key representing the requested VerificationLevel.
         *
         * @return The VerificationLevel related to the provided key, or {@link #UNKNOWN VerificationLevel.UNKNOWN} if the key is not recognized.
         */
        @Nonnull
        public static VerificationLevel fromKey(int key) {
            for (VerificationLevel level : VerificationLevel.values()) {
                if (level.getKey() == key) {
                    return level;
                }
            }
            return UNKNOWN;
        }
    }

    /**
     * Represents the Notification-level of the Guild.
     * The Verification-Level determines what messages you receive pings for.
     * <p>
     * <br><b>All_Messages</b>   {@literal ->} Every message sent in this guild will result in a message ping.
     * <br><b>Mentions_Only</b>  {@literal ->} Only messages that specifically mention will result in a ping.
     */
    enum NotificationLevel {
        ALL_MESSAGES(0),
        MENTIONS_ONLY(1),
        UNKNOWN(-1);

        private final int key;

        NotificationLevel(int key) {
            this.key = key;
        }

        /**
         * The Discord id key used to represent this NotificationLevel.
         *
         * @return Integer id for this NotificationLevel.
         */
        public int getKey() {
            return key;
        }

        /**
         * Used to retrieve a {@link net.dv8tion.jda.api.entities.Guild.NotificationLevel NotificationLevel} based
         * on the Discord id key.
         *
         * @param  key
         *         The Discord id key representing the requested NotificationLevel.
         *
         * @return The NotificationLevel related to the provided key, or {@link #UNKNOWN NotificationLevel.UNKNOWN} if the key is not recognized.
         */
        @Nonnull
        public static NotificationLevel fromKey(int key) {
            for (NotificationLevel level : values()) {
                if (level.getKey() == key) {
                    return level;
                }
            }
            return UNKNOWN;
        }
    }

    /**
     * Represents the Multifactor Authentication level required by the Guild.
     * <br>The MFA Level restricts administrator functions to account with MFA Level equal to or higher than that set by the guild.
     * <p>
     * <br><b>None</b>             {@literal ->} There is no MFA level restriction on administrator functions in this guild.
     * <br><b>Two_Factor_Auth</b>  {@literal ->} Users must have 2FA enabled on their account to perform administrator functions.
     */
    enum MFALevel {
        NONE(0),
        TWO_FACTOR_AUTH(1),
        UNKNOWN(-1);

        private final int key;

        MFALevel(int key) {
            this.key = key;
        }

        /**
         * The Discord id key used to represent this MFALevel.
         *
         * @return Integer id for this MFALevel.
         */
        public int getKey() {
            return key;
        }

        /**
         * Used to retrieve a {@link net.dv8tion.jda.api.entities.Guild.MFALevel MFALevel} based
         * on the Discord id key.
         *
         * @param  key
         *         The Discord id key representing the requested MFALevel.
         *
         * @return The MFALevel related to the provided key, or {@link #UNKNOWN MFALevel.UNKNOWN} if the key is not recognized.
         */
        @Nonnull
        public static MFALevel fromKey(int key) {
            for (MFALevel level : values()) {
                if (level.getKey() == key) {
                    return level;
                }
            }
            return UNKNOWN;
        }
    }

    /**
     * The Explicit-Content-Filter Level of a Guild.
     * <br>This decides whom's messages should be scanned for explicit content.
     */
    enum ExplicitContentLevel {
        OFF(0, "Don't scan any messages."),
        NO_ROLE(1, "Scan messages from members without a role."),
        ALL(2, "Scan messages sent by all members."),

        UNKNOWN(-1, "Unknown filter level!");

        private final int key;
        private final String description;

        ExplicitContentLevel(int key, String description) {
            this.key = key;
            this.description = description;
        }

        /**
         * The key for this level
         *
         * @return key
         */
        public int getKey() {
            return key;
        }

        /**
         * Description of this level in the official Discord Client (as of 5th May, 2017)
         *
         * @return Description for this level
         */
        @Nonnull
        public String getDescription() {
            return description;
        }

        @Nonnull
        public static ExplicitContentLevel fromKey(int key) {
            for (ExplicitContentLevel level : values()) {
                if (level.key == key) {
                    return level;
                }
            }
            return UNKNOWN;
        }
    }

    /**
     * Represents the NSFW level for this guild.
     */
    enum NSFWLevel {
        /**
         * Discord has not rated this guild.
         */
        DEFAULT(0),
        /**
         * Is classified as a NSFW server
         */
        EXPLICIT(1),
        /**
         * Doesn't classify as a NSFW server
         */
        SAFE(2),
        /**
         * Is classified as NSFW and has an age restriction in place
         */
        AGE_RESTRICTED(3),
        /**
         * Placeholder for unsupported levels.
         */
        UNKNOWN(-1);

        private final int key;

        NSFWLevel(int key) {
            this.key = key;
        }

        /**
         * The Discord id key used to represent this NSFW level.
         *
         * @return Integer id for this NSFW level.
         */
        public int getKey() {
            return key;
        }

        /**
         * Used to retrieve a {@link net.dv8tion.jda.api.entities.Guild.NSFWLevel NSFWLevel} based
         * on the Discord id key.
         *
         * @param  key
         *         The Discord id key representing the requested NSFWLevel.
         *
         * @return The NSFWLevel related to the provided key, or {@link #UNKNOWN NSFWLevel.UNKNOWN} if the key is not recognized.
         */
        @Nonnull
        public static NSFWLevel fromKey(int key) {
            for (NSFWLevel level : values()) {
                if (level.getKey() == key) {
                    return level;
                }
            }
            return UNKNOWN;
        }
    }

    /**
     * The boost tier for this guild.
     * <br>Each tier unlocks new perks for a guild that can be seen in the {@link #getFeatures() features}.
     */
    enum BoostTier {
        /**
         * The default tier.
         * <br>Unlocked at 0 boosters.
         */
        NONE(0, 96000, 50),
        /**
         * The first tier.
         * <br>Unlocked at 2 boosters.
         */
        TIER_1(1, 128000, 100),
        /**
         * The second tier.
         * <br>Unlocked at 7 boosters.
         */
        TIER_2(2, 256000, 150),
        /**
         * The third tier.
         * <br>Unlocked at 14 boosters.
         */
        TIER_3(3, 384000, 250),
        /**
         * Placeholder for future tiers.
         */
        UNKNOWN(-1, Integer.MAX_VALUE, Integer.MAX_VALUE);

        private final int key;
        private final int maxBitrate;
        private final int maxEmojis;

        BoostTier(int key, int maxBitrate, int maxEmojis) {
            this.key = key;
            this.maxBitrate = maxBitrate;
            this.maxEmojis = maxEmojis;
        }

        /**
         * The API key used to represent this tier, identical to the ordinal.
         *
         * @return The key
         */
        public int getKey() {
            return key;
        }

        /**
         * The maximum bitrate that can be applied to voice channels when this tier is reached.
         *
         * @return The maximum bitrate
         *
         * @see    net.dv8tion.jda.api.entities.Guild#getMaxBitrate()
         */
        public int getMaxBitrate() {
            return maxBitrate;
        }

        /**
         * The maximum amount of custom emojis a guild can have when this tier is reached.
         *
         * @return The maximum emojis
         *
         * @see    net.dv8tion.jda.api.entities.Guild#getMaxEmojis()
         */
        public int getMaxEmojis() {
            return maxEmojis;
        }

        /**
         * The maximum size for files that can be uploaded to this Guild.
         *
         * @return The maximum file size of this Guild
         *
         * @see    net.dv8tion.jda.api.entities.Guild#getMaxFileSize()
         */
        public long getMaxFileSize() {
            if (key == 2) {
                return 50 << 20;
            } else if (key == 3) {
                return 100 << 20;
            }
            return Message.MAX_FILE_SIZE;
        }

        /**
         * Resolves the provided API key to the boost tier.
         *
         * @param  key
         *         The API key
         *
         * @return The BoostTier or {@link #UNKNOWN}
         */
        @Nonnull
        public static BoostTier fromKey(int key) {
            for (BoostTier tier : values()) {
                if (tier.key == key) {
                    return tier;
                }
            }
            return UNKNOWN;
        }
    }

    /**
     * Represents a Ban object.
     *
     * @see #retrieveBanList()
     * @see <a href="https://discord.com/developers/docs/resources/guild#ban-object" target="_blank">Discord Docs: Ban Object</a>
     */
    class Ban {
        protected final User user;
        protected final String reason;

        public Ban(User user, String reason) {
            this.user = user;
            this.reason = reason;
        }

        /**
         * The {@link net.dv8tion.jda.api.entities.User User} that was banned
         *
         * @return The banned User
         */
        @Nonnull
        public User getUser() {
            return user;
        }

        /**
         * The reason why this user was banned
         *
         * @return The reason for this ban, or {@code null}
         */
        @Nullable
        public String getReason() {
            return reason;
        }

        @Override
        public String toString() {
            return new EntityString(this)
                    .addMetadata("user", user)
                    .addMetadata("reason", reason)
                    .toString();
        }
    }

    /**
     * Meta-Data for a Guild
     */
    class MetaData {
        private final int memberLimit;
        private final int presenceLimit;
        private final int approximatePresences;
        private final int approximateMembers;

        public MetaData(int memberLimit, int presenceLimit, int approximatePresences, int approximateMembers) {
            this.memberLimit = memberLimit;
            this.presenceLimit = presenceLimit;
            this.approximatePresences = approximatePresences;
            this.approximateMembers = approximateMembers;
        }

        /**
         * The active member limit for this guild.
         * <br>This limit restricts how many users can be member for this guild at once.
         *
         * @return The member limit
         */
        public int getMemberLimit() {
            return memberLimit;
        }

        /**
         * The active presence limit for this guild.
         * <br>This limit restricts how many users can be connected/online for this guild at once.
         *
         * @return The presence limit
         */
        public int getPresenceLimit() {
            return presenceLimit;
        }

        /**
         * The approximate number of online members in this guild.
         *
         * @return The approximate presence count
         */
        public int getApproximatePresences() {
            return approximatePresences;
        }

        /**
         * The approximate number of members in this guild.
         *
         * @return The approximate member count
         */
        public int getApproximateMembers() {
            return approximateMembers;
        }
    }
}
