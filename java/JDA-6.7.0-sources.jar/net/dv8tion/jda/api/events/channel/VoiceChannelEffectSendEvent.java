/*
 * Copyright 2015 Austin Keener, Michael Ritter, Florian Spieß, and the JDA contributors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.dv8tion.jda.api.events.channel;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.entities.channel.VoiceChannelEffect;
import net.dv8tion.jda.api.entities.channel.concrete.VoiceChannel;
import net.dv8tion.jda.api.requests.GatewayIntent;

import javax.annotation.Nonnull;

/**
 * Indicates that a {@link VoiceChannelEffect voice channel effect} was sent in a {@link VoiceChannel}.
 *
 * <p><b>Requirements</b><br>
 * This event requires {@link GatewayIntent#GUILD_VOICE_STATES} to be enabled.
 */
public class VoiceChannelEffectSendEvent extends GenericChannelEvent {
    private final VoiceChannelEffect effect;

    public VoiceChannelEffectSendEvent(@Nonnull JDA api, long responseNumber, VoiceChannelEffect effect) {
        super(api, responseNumber, effect.getChannel());
        this.effect = effect;
    }

    /**
     * The voice channel the effect was sent to.
     *
     * @return The voice channel the effect was sent to.
     */
    @Nonnull
    public VoiceChannel getVoiceChannel() {
        return effect.getChannel();
    }

    /**
     * The effect that was sent.
     *
     * @return The effect that was sent.
     */
    @Nonnull
    public VoiceChannelEffect getEffect() {
        return effect;
    }
}
